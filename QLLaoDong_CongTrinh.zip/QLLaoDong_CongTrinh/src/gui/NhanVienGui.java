package gui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

public class NhanVienGui extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    private JTextField txtMa;
    private JComboBox<String> cboQuan;
    private JComboBox<String> cboPhuong;
    private JTextField txtSoNha;
    private JTextField txtDuong;
    private JTextField txtTen;
    private JTextField txtSDT;
    private JDateChooser ngaySinh;
    private JComboBox<String> cboGioiTinh;
    private JComboBox<String> cboChucVu;

    private JButton btnThem;
    private JButton btnXoa;
    private JButton btnSua;
    private JButton btnXoaTrang;
    private JButton btnTim;

    private JButton btnStart;
    private JButton btnEnd;
    private JButton btnNext;
    private JButton btnPrevious;
    private JLabel lblPage;

    private JTextField txtTimMa;
    private JTextField txtTimTen;
    private JTextField txtTimSDT;
    private JComboBox<String> cboTimChucVu;

    public NhanVienGui() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel pnTitle = new JPanel();
        JLabel lblTitle = new JLabel("QUAN LY NHAN VIEN");
        lblTitle.setFont(new Font("arial", Font.BOLD, 20));
        pnTitle.add(lblTitle);
        this.add(pnTitle);

        JPanel pnCenter = new JPanel();
        pnCenter.setLayout(new BoxLayout(pnCenter, BoxLayout.Y_AXIS));
        this.add(pnCenter);

        // table
        String[] header = { "Ma NV", "Ten nhan vien", "Dia chi", "So dien thoai", "Ngay sinh", "Gioi tinh", "Chuc vu" };
        tableModel = new DefaultTableModel(header, 0);
        table = new JTable(tableModel);
        table.getTableHeader().setDefaultRenderer(new PhanCongGui.SimpleHeaderRenderer());
        pnCenter.add(new JScrollPane(table));

        // =======================
        // page
        JPanel pnPagination = new JPanel();
        pnPagination.setLayout(new FlowLayout(FlowLayout.LEFT));
        btnStart = new JButton(CongTrinhGui.resizeIcon("images/rewind-button.png", 12, 12));
        btnPrevious = new JButton(CongTrinhGui.resizeIcon("images/previous.png", 12, 12));
        btnEnd = new JButton(CongTrinhGui.resizeIcon("images/forward-button.png", 12, 12));
        btnNext = new JButton(CongTrinhGui.resizeIcon("images/next.png", 12, 12));
        lblPage = new JLabel("1", SwingConstants.CENTER);
        lblPage.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        pnPagination.add(btnStart);
        pnPagination.add(btnPrevious);
        pnPagination.add(lblPage);
        pnPagination.add(btnNext);
        pnPagination.add(btnEnd);
        pnCenter.add(pnPagination);

        JPanel pnInput = new JPanel();
        pnInput.setLayout(new BoxLayout(pnInput, BoxLayout.Y_AXIS));
        pnInput.setBorder(BorderFactory.createEmptyBorder(10, 50, 10, 50));
        pnCenter.add(pnInput);

        JPanel pnTitleTT = new JPanel();
        JLabel lblTitleTT = new JLabel("Thong Tin Nhan Vien");
        lblTitleTT.setFont(new Font("arial", Font.BOLD, 20));
        pnTitleTT.add(lblTitleTT);
        pnInput.add(pnTitleTT);

        // ==================================================
        JPanel pnMaTen = new JPanel();
        pnMaTen.setLayout(new BoxLayout(pnMaTen, BoxLayout.X_AXIS));
        pnMaTen.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblMa = new JLabel("  Ma nhan vien  ");
        txtMa = new JTextField();
        txtMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMa.getMinimumSize().height));

        JLabel lblTen = new JLabel("  Ten nhan vien  ");
        txtTen = new JTextField();
        txtTen.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTen.getMinimumSize().height));

        pnMaTen.add(lblMa);
        pnMaTen.add(txtMa);
        pnMaTen.add(lblTen);
        pnMaTen.add(txtTen);
        pnInput.add(pnMaTen);

        // ========================================
        JPanel pnDD = new JPanel();
        pnDD.setLayout(new BoxLayout(pnDD, BoxLayout.X_AXIS));
        pnDD.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblQuan = new JLabel("  Quan  ");
        cboQuan = new JComboBox<>();
        cboQuan.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboQuan.getMinimumSize().height));

        JLabel lblPhuong = new JLabel("  Phuong  ");
        cboPhuong = new JComboBox<>();
        cboPhuong.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboPhuong.getMinimumSize().height));

        JLabel lblSoNha = new JLabel("  So nha  ");
        txtSoNha = new JTextField();
        txtSoNha.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtSoNha.getMinimumSize().height));

        JLabel lblDuong = new JLabel("  Duong  ");
        txtDuong = new JTextField();
        txtDuong.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtDuong.getMinimumSize().height));

        pnDD.add(lblQuan);
        pnDD.add(cboQuan);
        pnDD.add(lblPhuong);
        pnDD.add(cboPhuong);
        pnDD.add(lblSoNha);
        pnDD.add(txtSoNha);
        pnDD.add(lblDuong);
        pnDD.add(txtDuong);
        pnInput.add(pnDD);

        // ===========================
        JPanel pnDT = new JPanel();
        pnDT.setLayout(new BoxLayout(pnDT, BoxLayout.X_AXIS));
        pnDT.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblDT = new JLabel("  So dien thoai  ");
        txtSDT = new JTextField();
        txtSDT.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtSDT.getMinimumSize().height));

        JLabel lblNgay = new JLabel("  Ngay sinh  ");
        ngaySinh = new JDateChooser();
        ngaySinh.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngaySinh.getMinimumSize().height));

        JLabel lblGT = new JLabel("  Gioi tinh  ");
        cboGioiTinh = new JComboBox<>();
        cboGioiTinh.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboGioiTinh.getMinimumSize().height));

        JLabel lblChucVu = new JLabel("  Chuc vu  ");
        cboChucVu = new JComboBox<>();
        cboChucVu.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboChucVu.getMinimumSize().height));

        pnDT.add(lblDT);
        pnDT.add(txtSDT);
        pnDT.add(lblNgay);
        pnDT.add(ngaySinh);
        pnDT.add(lblGT);
        pnDT.add(cboGioiTinh);
        pnDT.add(lblChucVu);
        pnDT.add(cboChucVu);
        pnInput.add(pnDT);

        lblQuan.setPreferredSize(lblMa.getPreferredSize());

        // =====================
        // tac vu
        JPanel pnTacVu = new JPanel();
        pnTacVu.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        btnThem = new JButton("Them");
        btnXoa = new JButton("Xoa");
        btnSua = new JButton("Sua");
        btnXoaTrang = new JButton("Xoa trang");

        pnTacVu.add(btnThem);
        pnTacVu.add(btnXoa);
        pnTacVu.add(btnSua);
        pnTacVu.add(btnXoaTrang);
        pnInput.add(pnTacVu);

        // ====================
        // tim kiem
        JPanel pnTitleTim = new JPanel();
        JLabel lblTitleTim = new JLabel("Tim Kiem Nhan Vien");
        lblTitleTim.setFont(new Font("arial", Font.BOLD, 20));
        pnTitleTim.add(lblTitleTim);
        pnInput.add(pnTitleTim);

        // =================
        // tim ma ten
        JPanel pnTimMaTen = new JPanel();
        pnTimMaTen.setLayout(new BoxLayout(pnTimMaTen, BoxLayout.X_AXIS));
        pnTimMaTen.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblTimMa = new JLabel("  Ma nhan vien  ");
        txtTimMa = new JTextField();
        txtTimMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimMa.getMinimumSize().height));

        JLabel lblTimTen = new JLabel("  Ten Nhan vien  ");
        txtTimTen = new JTextField();
        txtTimTen.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimTen.getMinimumSize().height));

        pnTimMaTen.add(lblTimMa);
        pnTimMaTen.add(txtTimMa);
        pnTimMaTen.add(lblTimTen);
        pnTimMaTen.add(txtTimTen);
        pnInput.add(pnTimMaTen);

        JPanel pnSDTChucVu = new JPanel();
        pnSDTChucVu.setLayout(new BoxLayout(pnSDTChucVu, BoxLayout.X_AXIS));
        pnSDTChucVu.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel lblTimSDT = new JLabel("  So dien thoai  ");
        txtTimSDT = new JTextField();
        txtTimSDT.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimSDT.getMinimumSize().height));

        JLabel lblTimChucVu = new JLabel("  Chuc vu  ");
        cboTimChucVu = new JComboBox<>();
        cboTimChucVu.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboTimChucVu.getMinimumSize().height));

        pnSDTChucVu.add(lblTimSDT);
        pnSDTChucVu.add(txtTimSDT);
        pnSDTChucVu.add(lblTimChucVu);
        pnSDTChucVu.add(cboTimChucVu);
        pnInput.add(pnSDTChucVu);

        // =====================
        // button tim
        JPanel pnBtnTim = new JPanel();
        pnBtnTim.setLayout(new FlowLayout(FlowLayout.LEFT));
        btnTim = new JButton("Tim");
        pnBtnTim.add(btnTim);
        pnInput.add(pnBtnTim);

    }

}
