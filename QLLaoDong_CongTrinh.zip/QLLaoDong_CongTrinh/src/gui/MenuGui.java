package gui;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MenuGui extends JPanel implements MouseListener {

    private static final long serialVersionUID = 1L;
    private JPanel pnCongTrinh;
    private JPanel pnLaoDong;
    private JPanel pnNhanVien;
    private JPanel pnPhanCong;
    private JPanel pnCongViec;
    private JPanel pnTroGiup;
    private JPanel pnDoiMK;
    private JPanel pnThoat;

    public MenuGui() throws IOException {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        this.setBackground(Color.lightGray);
        this.setPreferredSize(new Dimension(300, 0));
        this.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));

        JPanel pnTitle = new JPanel();
        JLabel lblTitle = new JLabel("Quản lý");
        lblTitle.setFont(new Font("arial", Font.BOLD, 22));
        pnTitle.add(lblTitle);

        this.add(pnTitle);

        // image profile
        JLabel picLabel = createLabelImage("images/profile.png");
        JPanel pnImg = new JPanel();
        pnImg.add(picLabel);
        this.add(pnImg);

        // list menu
        pnCongTrinh = createMenuSelect("images/cityscape.png", "Cong Trinh");
        this.add(pnCongTrinh);

        pnLaoDong = createMenuSelect("images/worker.png", "Lao Dong");
        this.add(pnLaoDong);

        pnNhanVien = createMenuSelect("images/employee.png", "Nhan Vien");
        this.add(pnNhanVien);

        pnPhanCong = createMenuSelect("images/schedule.png", "Phan Cong");
        this.add(pnPhanCong);

        pnCongViec = createMenuSelect("images/portfolio.png", "Cong Viec");
        this.add(pnCongViec);

        pnTroGiup = createMenuSelect("images/help.png", "Tro Giup");
        this.add(pnTroGiup);

        pnDoiMK = createMenuSelect("images/key.png", "Doi Mat Khau");
        this.add(pnDoiMK);

        pnThoat = createMenuSelect("images/logout.png", "Thoat");
        this.add(pnThoat);

    }

    public JLabel createLabelImage(String path) throws IOException {
        BufferedImage myPicture = ImageIO.read(new File(path));
        JLabel picLabel = new JLabel(new ImageIcon(myPicture));
        return picLabel;
    }

    /**
     * 
     * @param pathImg
     * @param labelName
     * @return
     * @throws IOException
     */
    public JPanel createMenuSelect(String pathImg, String labelName) throws IOException {
        JPanel temp = new JPanel();
        JLabel lblImg = createLabelImage(pathImg);
        JLabel lblTitle = new JLabel(labelName);
        lblTitle.setFont(new Font("arial", Font.BOLD, 15));
        temp.setLayout(new GridLayout(1, 2));
        temp.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY));
        temp.add(lblImg);
        temp.add(lblTitle);
        temp.setBackground(new Color(102, 167, 197));
        temp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        temp.addMouseListener(this);
        // hover event
        temp.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                temp.setBackground(new Color(68, 144, 148));
            }

            @Override
            public void mouseExited(MouseEvent e) {
                temp.setBackground(new Color(102, 167, 197));
            }
        });
        return temp;
    }

    private void removeAndAddd(JComponent comp) {
        MainGui.pnCenter.remove(MainGui.pnCenter.getComponent(0));
        MainGui.pnCenter.revalidate();
        MainGui.pnCenter.repaint();
        MainGui.pnCenter.add(comp);
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        Object o = e.getSource();
        if (o == pnCongTrinh) {
            removeAndAddd(MainGui.pnCongTrinh);

        } else if (o == pnLaoDong) {
            removeAndAddd(MainGui.pnLaoDong);
        } else if (o == pnNhanVien) {
            removeAndAddd(MainGui.pnNhanVien);
        } else if (o == pnPhanCong) {
            removeAndAddd(MainGui.pnPhanCong);
        } else if (o == pnCongViec) {
            removeAndAddd(MainGui.pnCongViec);
        } else if (o == pnTroGiup) {
            //
        } else if (o == pnDoiMK) {
            DoiMatKhauGui doiMK = new DoiMatKhauGui();
            doiMK.setVisible(true);
        } else {
            int t = JOptionPane.showConfirmDialog(null, "Ban co muon thoat", "Thong Bao", JOptionPane.YES_NO_OPTION);
            if (t == JOptionPane.YES_OPTION) {
                System.exit(1);
            }
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

}
