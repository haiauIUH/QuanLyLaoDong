package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import com.toedter.calendar.JDateChooser;

public class PhanCongGui extends JPanel {
    private JTextField txtMaLaoDong;
    private JTextField txtTenLaoDong;
    private JTextField txtSoDienThoai;
    private JComboBox<String> cboCongViec;
    private JDateChooser ngayThucHien;
    private JDateChooser ngayHoanThanh;
    private JTextField txtSoLuong;
    private JButton btnPhanCong;

    // trong chi tiet phan cong
    private JTextField txtTimMa;
    private JTextField txtTimTen;
    private JComboBox<String> cboTimCongViec;
    private JButton btnTim;
    private JButton btnXoa;

    private JTable tableLaoDong;
    private DefaultTableModel tableModelLaoDong;

    private JTable tableChiTietPhanCong;
    private DefaultTableModel tableModelChiTietPhanCong;

    public static class SimpleHeaderRenderer extends JLabel implements TableCellRenderer {
        public SimpleHeaderRenderer() {
            setFont(new Font("Consolas", Font.BOLD, 12));
            setForeground(Color.BLUE);
            setBorder(BorderFactory.createEtchedBorder());
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value,
                boolean isSelected, boolean hasFocus, int row, int column) {
            setText(value.toString());
            return this;
        }
    }

    public PhanCongGui() {
        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel pnTitle = new JPanel();
        JLabel lblTitle = new JLabel("PHAN CONG LAO DONG");
        lblTitle.setFont(new Font("arial", Font.BOLD, 20));
        pnTitle.add(lblTitle);
        this.add(pnTitle);

        // ==============
        JPanel pnPhanCong = new JPanel();
        pnPhanCong.setLayout(new BoxLayout(pnPhanCong, BoxLayout.Y_AXIS));
        this.add(pnPhanCong);

        // ===============
        // thong tin chi tiet cua cong trinh bao gom cong viec ngay thuc hien....
        JPanel pnThongTinChiTiet = new JPanel();
        pnThongTinChiTiet.setBorder(new CompoundBorder(
                BorderFactory.createTitledBorder("Thong tin cong viec can phan cong"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        pnThongTinChiTiet.setLayout(new BoxLayout(pnThongTinChiTiet, BoxLayout.Y_AXIS));

        JPanel pnTemp = new JPanel();
        pnTemp.setLayout(new BoxLayout(pnTemp, BoxLayout.X_AXIS));
        JLabel lblCongViec = new JLabel("  Cong viec  ");
        cboCongViec = new JComboBox<>();
        cboCongViec.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboCongViec.getMinimumSize().height));
        JLabel lblNgayThucHien = new JLabel("  Ngay thuc hien  ");
        ngayThucHien = new JDateChooser();
        ngayThucHien.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngayThucHien.getMinimumSize().height));
        JLabel lblNgayHoanThanh = new JLabel("  Ngay hoan thanh  ");
        ngayHoanThanh = new JDateChooser();
        ngayHoanThanh.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngayHoanThanh.getMinimumSize().height));
        pnTemp.add(lblCongViec);
        pnTemp.add(cboCongViec);
        pnTemp.add(lblNgayThucHien);
        pnTemp.add(ngayThucHien);
        pnTemp.add(lblNgayHoanThanh);
        pnTemp.add(ngayHoanThanh);
        pnThongTinChiTiet.add(pnTemp);
        pnPhanCong.add(pnThongTinChiTiet);

        JPanel pnSoLuong = new JPanel();
        pnSoLuong.setLayout(new FlowLayout(FlowLayout.LEFT));
        JLabel lblSoLuong = new JLabel(" So luong");
        lblSoLuong.setPreferredSize(lblCongViec.getPreferredSize());
        txtSoLuong = new JTextField(10);
        btnPhanCong = new JButton("Phan cong");
        JLabel lblInfo = new JLabel("Ban co the chon so luong hoac chon trong bang uu tien bang");
        lblInfo.setForeground(Color.red);
        pnSoLuong.add(lblSoLuong);
        pnSoLuong.add(txtSoLuong);
        pnSoLuong.add(btnPhanCong);
        pnSoLuong.add(lblInfo);
        pnThongTinChiTiet.add(pnSoLuong);
        // ======================
        // filter lao dong
        JPanel pnDanhSachLaoDong = new JPanel();
        pnDanhSachLaoDong.setLayout(new BoxLayout(pnDanhSachLaoDong, BoxLayout.Y_AXIS));
        pnDanhSachLaoDong.setBorder(new CompoundBorder(
                BorderFactory.createTitledBorder("Danh sach lao dong"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        pnPhanCong.add(pnDanhSachLaoDong);

        JPanel pnInputFilterLD = new JPanel();
        pnInputFilterLD.setLayout(new GridLayout(1, 6));
        pnDanhSachLaoDong.add(pnInputFilterLD);
        JLabel lblMa = new JLabel("  Ma lao dong  ");
        lblCongViec.setPreferredSize(lblMa.getPreferredSize());
        txtMaLaoDong = new JTextField();
        JLabel lblTen = new JLabel("  Ten lao dong  ");
        txtTenLaoDong = new JTextField();
        JLabel lblSDT = new JLabel("  So dien thoai  ");
        txtSoDienThoai = new JTextField();
        pnInputFilterLD.add(lblMa);
        pnInputFilterLD.add(txtMaLaoDong);
        pnInputFilterLD.add(lblTen);
        pnInputFilterLD.add(txtTenLaoDong);
        pnInputFilterLD.add(lblSDT);
        pnInputFilterLD.add(txtSoDienThoai);

        JPanel pnTableLD = new JPanel();
        pnTableLD.setLayout(new BorderLayout());
        pnTableLD.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        String[] header = "Ma LD;TenLD;Dia chi;So dienThoai;Ngay sinh;Gioi tinh;CMND".split(";");
        tableModelLaoDong = new DefaultTableModel(header, 0);
        tableLaoDong = new JTable(tableModelLaoDong);
        tableLaoDong.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer());
        pnTableLD.add(new JScrollPane(tableLaoDong));
        pnDanhSachLaoDong.add(pnTableLD);

        // ============
        // filter danh sach
        JPanel pnChiTietPhanCong = new JPanel();
        pnChiTietPhanCong.setLayout(new BoxLayout(pnChiTietPhanCong, BoxLayout.Y_AXIS));
        pnChiTietPhanCong.setBorder(new CompoundBorder(
                BorderFactory.createTitledBorder("Thong tin chi tiet phan cong"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)));
        this.add(pnChiTietPhanCong);

        JPanel pnFilterChitiet = new JPanel();
        pnFilterChitiet.setLayout(new BoxLayout(pnFilterChitiet, BoxLayout.X_AXIS));
        pnFilterChitiet.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        JLabel lblTimMa = new JLabel("Ma lao dong  ");
        txtTimMa = new JTextField();
        txtTimMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimMa.getMinimumSize().height));

        JLabel lblTimTen = new JLabel("  Ten LD  ");
        txtTimTen = new JTextField();
        txtTimTen.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimTen.getMinimumSize().height));

        JLabel lblTimCongViec = new JLabel("  Cong viec  ");
        cboTimCongViec = new JComboBox<>();
        cboTimCongViec.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboTimCongViec.getMinimumSize().height));
        JLabel lblTemp = new JLabel("   ");
        btnTim = new JButton("Tim");
        btnXoa = new JButton("Xoa");

        pnFilterChitiet.add(lblTimMa);
        pnFilterChitiet.add(txtTimMa);
        pnFilterChitiet.add(lblTimTen);
        pnFilterChitiet.add(txtTimTen);
        pnFilterChitiet.add(lblTimCongViec);
        pnFilterChitiet.add(cboTimCongViec);
        pnFilterChitiet.add(lblTemp);
        pnFilterChitiet.add(btnTim);
        pnFilterChitiet.add(lblTemp);
        pnFilterChitiet.add(btnXoa);
        pnChiTietPhanCong.add(pnFilterChitiet);

        header = "Ma LD;Ten LD;Ngay thuc hien;Ngay hoan thanh;Cong viec".split(";");
        tableModelChiTietPhanCong = new DefaultTableModel(header, 0);
        tableChiTietPhanCong = new JTable(tableModelChiTietPhanCong);
        tableChiTietPhanCong.getTableHeader().setDefaultRenderer(new SimpleHeaderRenderer());
        pnChiTietPhanCong.add(new JScrollPane(tableChiTietPhanCong));

    }
}
