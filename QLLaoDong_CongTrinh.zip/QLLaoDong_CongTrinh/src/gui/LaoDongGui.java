package gui;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

public class LaoDongGui extends JPanel {
    private JTable table;
    private DefaultTableModel tableModel;

    private JTextField txtMaLaoDong;
    private JTextField txtTenLaoDong;
    private JTextField txtSoDienThoai;
    private JTextField txtCMND;
    private JTextField txtMatKhau;
    private JComboBox<String> cboQuan;
    private JComboBox<String> cboPhuong;
    private JTextField txtSoNha;
    private JTextField txtDuong;
    private JDateChooser ngaySinh;
    private JComboBox<String> cboGioiTinh;
    private JComboBox<String> cboTrangThai;
    private JComboBox<String> cboTrinhDo;

    private JButton btnThem;
    private JButton btnSua;
    private JButton btnXoa;
    private JButton btnXoaTrang;
    private JButton btnTim;

    private JButton btnStart;
    private JButton btnEnd;
    private JButton btnNext;
    private JButton btnPrevious;
    private JLabel lblPage;

    private JTextField txtTimMa;
    private JTextField txtTimTen;
    private JTextField txtTimSDT;
    private JTextField txtTimCMND;

    public LaoDongGui() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel pnTitle = new JPanel();
        JLabel lblTitle = new JLabel("QUAN LY LAO DONG");
        lblTitle.setFont(new Font("arial", Font.BOLD, 20));
        pnTitle.add(lblTitle);
        this.add(pnTitle);

        JPanel pnCenter = new JPanel();
        pnCenter.setLayout(new BoxLayout(pnCenter, BoxLayout.Y_AXIS));
        this.add(pnCenter);

        // add table
        String[] header = { "Ma LD", "Ten LD", "Dia chi", "So dien thoai", "Ngay sinh", "Gioi tinh", "CMND",
                "Trinh do" };
        tableModel = new DefaultTableModel(header, 0);
        table = new JTable(tableModel);
        table.getTableHeader().setDefaultRenderer(new PhanCongGui.SimpleHeaderRenderer());
        pnCenter.add(new JScrollPane(table));

        // =======================
        // page
        JPanel pnPagination = new JPanel();
        pnPagination.setLayout(new FlowLayout(FlowLayout.LEFT));
        btnStart = new JButton(CongTrinhGui.resizeIcon("images/rewind-button.png", 12, 12));
        btnPrevious = new JButton(CongTrinhGui.resizeIcon("images/previous.png", 12, 12));
        btnEnd = new JButton(CongTrinhGui.resizeIcon("images/forward-button.png", 12, 12));
        btnNext = new JButton(CongTrinhGui.resizeIcon("images/next.png", 12, 12));
        lblPage = new JLabel("1", SwingConstants.CENTER);
        lblPage.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));
        pnPagination.add(btnStart);
        pnPagination.add(btnPrevious);
        pnPagination.add(lblPage);
        pnPagination.add(btnNext);
        pnPagination.add(btnEnd);
        pnCenter.add(pnPagination);

        JPanel pnInput = new JPanel();
        pnInput.setLayout(new BoxLayout(pnInput, BoxLayout.Y_AXIS));
        pnInput.setBorder(BorderFactory.createEmptyBorder(10, 50, 30, 50));
        pnCenter.add(pnInput);

        JPanel pnThongTin = new JPanel();
        JLabel lblThongTin = new JLabel("Thong Tin");
        lblThongTin.setFont(new Font("arial", Font.BOLD, 20));
        pnThongTin.add(lblThongTin);
        pnInput.add(pnThongTin);

        JPanel pnMaTenLD = new JPanel();
        pnMaTenLD.setLayout(new BoxLayout(pnMaTenLD, BoxLayout.X_AXIS));
        pnMaTenLD.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblMaLD = new JLabel("  Ma lao dong  ");
        txtMaLaoDong = new JTextField();
        txtMaLaoDong.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMaLaoDong.getMinimumSize().height));

        JLabel lblTenLD = new JLabel("  Ten lao dong  ");
        txtTenLaoDong = new JTextField();
        txtTenLaoDong.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTenLaoDong.getMinimumSize().height));
        pnMaTenLD.add(lblMaLD);
        pnMaTenLD.add(txtMaLaoDong);
        pnMaTenLD.add(lblTenLD);
        pnMaTenLD.add(txtTenLaoDong);
        pnInput.add(pnMaTenLD);

        // =================
        JPanel pnDiaChi = new JPanel();
        pnDiaChi.setLayout(new BoxLayout(pnDiaChi, BoxLayout.X_AXIS));
        pnInput.add(pnDiaChi);
        pnDiaChi.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblQuan = new JLabel("  Quan");
        cboQuan = new JComboBox<>();
        cboQuan.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboQuan.getMinimumSize().height));

        JLabel lblPhuong = new JLabel("  Phuong  ");
        cboPhuong = new JComboBox<>();
        cboPhuong.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboPhuong.getMinimumSize().height));

        JLabel lblSoNha = new JLabel("  So nha  ");
        txtSoNha = new JTextField();
        txtSoNha.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtSoNha.getMinimumSize().height * 200));

        JLabel lblDuong = new JLabel("  Duong  ");
        txtDuong = new JTextField();
        txtDuong.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtDuong.getMinimumSize().height * 200));

        pnDiaChi.add(lblQuan);
        pnDiaChi.add(cboQuan);
        pnDiaChi.add(lblPhuong);
        pnDiaChi.add(cboPhuong);
        pnDiaChi.add(lblSoNha);
        pnDiaChi.add(txtSoNha);
        pnDiaChi.add(lblDuong);
        pnDiaChi.add(txtDuong);

        // ===========================================
        // ngay sinh gioi tinh trang thai
        JPanel pnNgaySinh = new JPanel();
        pnNgaySinh.setLayout(new BoxLayout(pnNgaySinh, BoxLayout.X_AXIS));
        pnInput.add(pnNgaySinh);
        pnNgaySinh.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblNgaySinh = new JLabel("  Ngay sinh  ");
        ngaySinh = new JDateChooser();
        ngaySinh.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngaySinh.getMinimumSize().height));

        JLabel lblSoDienThoai = new JLabel("  So dien thoai  ");
        txtSoDienThoai = new JTextField();
        txtSoDienThoai.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtSoDienThoai.getMinimumSize().height));

        JLabel lblTrangThai = new JLabel("  Trang thai  ");
        cboTrangThai = new JComboBox<>();
        cboTrangThai.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboTrangThai.getMinimumSize().height));

        JLabel lblGioiTinh = new JLabel("  Gioi tinh  ");
        cboGioiTinh = new JComboBox<>();
        cboGioiTinh.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboGioiTinh.getMinimumSize().height));

        pnNgaySinh.add(lblSoDienThoai);
        pnNgaySinh.add(txtSoDienThoai);
        pnNgaySinh.add(lblGioiTinh);
        pnNgaySinh.add(cboGioiTinh);
        pnNgaySinh.add(lblNgaySinh);
        pnNgaySinh.add(ngaySinh);
        pnNgaySinh.add(lblTrangThai);
        pnNgaySinh.add(cboTrangThai);

        JPanel pnCMNN = new JPanel();
        pnCMNN.setLayout(new BoxLayout(pnCMNN, BoxLayout.X_AXIS));
        pnCMNN.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblCM = new JLabel("  CMND  ");
        txtCMND = new JTextField();
        txtCMND.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtCMND.getMinimumSize().height));

        JLabel lblMK = new JLabel("  Mat khau  ");
        txtMatKhau = new JTextField();
        txtMatKhau.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMatKhau.getMinimumSize().height));

        JLabel lblTrinhDo = new JLabel("  Trinh Do   ");
        cboTrinhDo = new JComboBox<>();
        cboTrinhDo.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboTrinhDo.getMinimumSize().height));

        pnCMNN.add(lblCM);
        pnCMNN.add(txtCMND);
        pnCMNN.add(lblMK);
        pnCMNN.add(txtMatKhau);
        pnCMNN.add(lblTrinhDo);
        pnCMNN.add(cboTrinhDo);
        pnInput.add(pnCMNN);

        lblMaLD.setPreferredSize(lblSoDienThoai.getPreferredSize());
        lblQuan.setPreferredSize(lblSoDienThoai.getPreferredSize());
        lblCM.setPreferredSize(lblSoDienThoai.getPreferredSize());

        JPanel pnTacVu = new JPanel();
        btnThem = new JButton("Them");
        btnXoa = new JButton("Xoa");
        btnSua = new JButton("Sua");
        btnXoaTrang = new JButton("Xoa trang");
        pnTacVu.add(btnThem);
        pnTacVu.add(btnXoa);
        pnTacVu.add(btnSua);
        pnTacVu.add(btnXoaTrang);
        pnInput.add(pnTacVu);

        JPanel pnTitleTim = new JPanel();
        JLabel lblTitleTim = new JLabel("Tim Kiem Lao Dong");
        lblTitleTim.setFont(new Font("arial", Font.BOLD, 20));
        pnTitleTim.add(lblTitleTim);
        pnInput.add(pnTitleTim);

        JPanel pnTimMa = new JPanel();
        pnTimMa.setLayout(new BoxLayout(pnTimMa, BoxLayout.X_AXIS));
        pnTimMa.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel lblTimMa = new JLabel("  Ma lao dong  ");
        txtTimMa = new JTextField();
        txtTimMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimMa.getMinimumSize().height));
        pnTimMa.add(lblTimMa);
        pnTimMa.add(txtTimMa);
        pnInput.add(pnTimMa);

        JPanel pnTimTen = new JPanel();
        pnTimTen.setLayout(new BoxLayout(pnTimTen, BoxLayout.X_AXIS));
        pnTimTen.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblTimTen = new JLabel("  Ten lao dong  ");
        txtTimTen = new JTextField();
        txtTimTen.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimTen.getMinimumSize().height));

        pnTimTen.add(lblTimTen);
        pnTimTen.add(txtTimTen);
        pnInput.add(pnTimTen);

        JPanel pnTimSDT = new JPanel();
        pnTimSDT.setLayout(new BoxLayout(pnTimSDT, BoxLayout.X_AXIS));
        pnTimSDT.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

        JLabel lblTimSDT = new JLabel("  So dien thoai  ");
        txtTimSDT = new JTextField();
        txtTimSDT.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimSDT.getMinimumSize().height));

        JLabel lblTimCMND = new JLabel("  CMND  ");
        txtTimCMND = new JTextField();
        txtTimCMND.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimCMND.getMinimumSize().height));

        pnTimSDT.add(lblTimSDT);
        pnTimSDT.add(txtTimSDT);
        pnTimSDT.add(lblTimCMND);
        pnTimSDT.add(txtTimCMND);
        pnInput.add(pnTimSDT);

        lblTimMa.setPreferredSize(lblSoDienThoai.getPreferredSize());
        lblTimTen.setPreferredSize(lblSoDienThoai.getPreferredSize());

        JPanel pnBTim = new JPanel();
        pnBTim.setLayout(new FlowLayout(FlowLayout.LEFT));
        btnTim = new JButton("Tim");
        pnBTim.add(btnTim);
        pnInput.add(pnBTim);

    }
}
