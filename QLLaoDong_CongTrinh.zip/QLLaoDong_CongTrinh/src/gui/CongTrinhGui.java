package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.toedter.calendar.JDateChooser;

import connectDB.ConnectDB;
import dao.CongTrinh_DAO;
import entity.CongTrinh;
import entity.DiaDiem;


public class CongTrinhGui extends JPanel implements ActionListener, MouseListener{

	private static final long serialVersionUID = 1L;
	private JTable table;
	private DefaultTableModel tableModel;
	private JTextField txtMaCongTrinh;
	private JTextField txtTenCongTrinh;
	private JComboBox<String> cboQuan;
	private JComboBox<String> cboPhuong;
	private JTextField txtSoNha;
	private JTextField txtDuong;
	private JTextField txtLoaiCongTrinh;
	private JComboBox<String> cboTrangThai;
	private JDateChooser ngayKhoiCong;
	private JDateChooser ngayHoanThanh;

	private JButton btnThem;
	private JButton btnXoa;
	private JButton btnSua;
	private JButton btnXoaTrang;
	private JButton btnTim;

	private JButton btnNext;
	private JButton btnEnd;
	private JButton btnPrevious;
	private JButton btnStart;
	private JLabel lblPage;
	
	private int tongSoMauTin;
	private int mauTinHienHanh;

	private JTextField txtTimMa;
	private JTextField txtTimLoai;
	private JComboBox<String> cboTimQuan;
	private JComboBox<String> cboTimPhuong;
	private JTextField txtTimDuong;
	private JTextField txtTimSoNha;
//	private ArrayList<CongTrinh> listCongtrinh;
//	private CongTrinh_DAO congTrinhDao;

	public CongTrinhGui() {
		this.setBackground(Color.lightGray);
		this.setLayout(new BorderLayout());

		JPanel pnTop = new JPanel();
		JLabel lblTitle = new JLabel("QUẢN LÝ CÔNG TRÌNH");
		lblTitle.setFont(new Font("arial", Font.BOLD, 20));
		pnTop.add(lblTitle);
		this.add(pnTop, BorderLayout.NORTH);

		JPanel pnCenter = new JPanel();
		pnCenter.setLayout(new BoxLayout(pnCenter, BoxLayout.Y_AXIS));
		this.add(pnCenter);

		// add table
		String[] header = {"Mã công trình", "Tên công trình", "Địa điểm", "Loại công trình", "Ngày khởi công", "Ngày hoàn thành",
				"Trạng thái"};
		tableModel = new DefaultTableModel(header, 0);
		table = new JTable(tableModel);
		table.getTableHeader().setDefaultRenderer(new PhanCongGui.SimpleHeaderRenderer());
		pnCenter.add(new JScrollPane(table));
		
		//ĐỌC DỮ LIỆU TỪ ARRAYLIST VÀO MODELTABLE
//		listCongtrinh = new ArrayList<CongTrinh>();
//		congTrinhDao = new CongTrinh_DAO();
//		DocDuLieuTuArrayListVaoModel();

		// button next previous
		JPanel pnPagination = new JPanel();
		pnPagination.setLayout(new FlowLayout(FlowLayout.LEFT));
		btnStart = new JButton(resizeIcon("images/rewind-button.png", 12, 12));
		btnPrevious = new JButton(resizeIcon("images/previous.png", 12, 12));

		lblPage = new JLabel("0", SwingConstants.CENTER);
		lblPage.setBorder(BorderFactory.createEmptyBorder(0, 5, 0, 5));

		btnNext = new JButton(resizeIcon("images/next.png", 12, 12));
		btnEnd = new JButton(resizeIcon("images/forward-button.png", 12, 12));
		pnPagination.add(btnStart);
		pnPagination.add(btnPrevious);
		pnPagination.add(lblPage);
		pnPagination.add(btnNext);
		pnPagination.add(btnEnd);

		pnCenter.add(pnPagination);

		// add title thong tin cong trinh
		JPanel pnTTCongTrinh = new JPanel();
		lblTitle = new JLabel("Thông tin công trình");
		lblTitle.setFont(new Font("arial", Font.BOLD, 20));
		pnTTCongTrinh.add(lblTitle);
		pnCenter.add(pnTTCongTrinh);

		// input
		JPanel pnInput = new JPanel();
		pnInput.setLayout(new BoxLayout(pnInput, BoxLayout.Y_AXIS));
		pnInput.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
		pnCenter.add(pnInput);

		// input ma va ten cong trinh
		JPanel pnMa_Ten = new JPanel();
		pnMa_Ten.setLayout(new BoxLayout(pnMa_Ten, BoxLayout.X_AXIS));
		pnMa_Ten.setBorder(BorderFactory.createEmptyBorder());
		JLabel lblMa = new JLabel("  Mã công trình  ");
		txtMaCongTrinh = new JTextField();
		txtMaCongTrinh.setMaximumSize(
				new Dimension(Integer.MAX_VALUE, txtMaCongTrinh.getMinimumSize().height * 200));
		pnMa_Ten.add(lblMa);
		pnMa_Ten.add(txtMaCongTrinh);

		JLabel lblTen = new JLabel("  Tên công trình  ");
		txtTenCongTrinh = new JTextField();
		txtTenCongTrinh.setMaximumSize(
				new Dimension(Integer.MAX_VALUE, txtTenCongTrinh.getMinimumSize().height * 200));
		pnMa_Ten.add(lblTen);
		pnMa_Ten.add(txtTenCongTrinh);
		pnInput.add(pnMa_Ten);

		// input dia diem
		JPanel pnDiaDiem = new JPanel();
		pnDiaDiem.setLayout(new BoxLayout(pnDiaDiem, BoxLayout.X_AXIS));
		pnDiaDiem.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		JLabel lblQuan = new JLabel("  Quận  ");
		cboQuan = new JComboBox<String>();
		cboQuan.setMaximumSize(
				new Dimension((int) (txtMaCongTrinh.getMaximumSize().width * 0.5),
						cboQuan.getMinimumSize().height));
		String[] item = " ,Quận 1,Quận Bình Tân,Quận 2,Quận Bình Thạnh,Quận 3,Quận Gò Vấp,Quận 4,Quận Phú Nhuận,Quận 5,Quận Tân Bình,Quận 6,Quận Tân Phú,Quận 7,Quận Thủ Đức,Quận 8,Huyện Bình Chánh,Quận 9,Huyện Cần Giờ,Quận 10,Huyện Củ Chi,Quận 11,Huyện Hóc Môn,Quận 12,Huyện Nhà Bè".split(",");
		cboQuan.setEditable(true);
		for (int i = 0; i < item.length; i++) {
			String string = item[i];
			cboQuan.addItem(string);
		}
		

		JLabel lblPhuong = new JLabel("  Phường  ");
		cboPhuong = new JComboBox<String>();
		cboPhuong.setMaximumSize(
				new Dimension((int) (txtMaCongTrinh.getMaximumSize().width * 0.5),
						cboPhuong.getMinimumSize().height));
		cboPhuong.setEditable(true);

		JLabel lblSoNha = new JLabel("  Số nhà  ");
		txtSoNha = new JTextField();
		txtSoNha.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				txtSoNha.getMinimumSize().height * 200));

		JLabel lblDuong = new JLabel("  Đường  ");
		txtDuong = new JTextField();
		txtDuong.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				txtDuong.getMinimumSize().height * 200));

		pnDiaDiem.add(lblQuan);
		pnDiaDiem.add(cboQuan);
		pnDiaDiem.add(lblPhuong);
		pnDiaDiem.add(cboPhuong);
		pnDiaDiem.add(lblSoNha);
		pnDiaDiem.add(txtSoNha);
		pnDiaDiem.add(lblDuong);
		pnDiaDiem.add(txtDuong);

		pnDiaDiem.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		pnInput.add(pnDiaDiem);

		// loai cong trinh trang thai
		JPanel pnLoai_trangThai = new JPanel();
		pnLoai_trangThai.setLayout(new BoxLayout(pnLoai_trangThai, BoxLayout.X_AXIS));

		JLabel lblLoai = new JLabel("  Loại công trình  ");
		txtLoaiCongTrinh = new JTextField();
		txtLoaiCongTrinh
				.setMaximumSize(new Dimension(Integer.MAX_VALUE,
						cboQuan.getMinimumSize().height));

		JLabel lblTrangThai = new JLabel("  Trạng thái  ");
		cboTrangThai = new JComboBox<String>();
		cboTrangThai.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				cboTrangThai.getMinimumSize().height));
		String[] items = " ,Hoàn thành,Đang thi công".split(",");
		for (int i = 0; i < items.length; i++) {
			String string = items[i];
			cboTrangThai.addItem(string);
		}
		cboTrangThai.setEditable(true);

		pnLoai_trangThai.add(lblLoai);
		pnLoai_trangThai.add(txtLoaiCongTrinh);
		pnLoai_trangThai.add(lblTrangThai);
		pnLoai_trangThai.add(cboTrangThai);
		pnLoai_trangThai.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		pnInput.add(pnLoai_trangThai);

		// ngay khoi cong va hoan thanh
		JPanel pnNgay = new JPanel();
		pnNgay.setLayout(new BoxLayout(pnNgay, BoxLayout.X_AXIS));

		JLabel lblKC = new JLabel("  Ngày khởi công  ");
		ngayKhoiCong = new JDateChooser();
		ngayKhoiCong.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngayKhoiCong.getMinimumSize().height * 200));

		JLabel lblHT = new JLabel("  Ngày hoàn thành  ");
		ngayHoanThanh = new JDateChooser();
		ngayHoanThanh.setMaximumSize(new Dimension(Integer.MAX_VALUE, ngayHoanThanh.getMinimumSize().height * 200));

		pnNgay.add(lblKC);
		pnNgay.add(ngayKhoiCong);
		pnNgay.add(lblHT);
		pnNgay.add(ngayHoanThanh);
		pnNgay.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		pnInput.add(pnNgay);

		lblMa.setPreferredSize(lblKC.getPreferredSize());
		lblQuan.setPreferredSize(lblKC.getPreferredSize());
		lblLoai.setPreferredSize(lblKC.getPreferredSize());

		// add button tac vu ==========================
		JPanel pnTacvu = new JPanel();
		btnThem = new JButton("Thêm");
		btnXoa = new JButton("Xóa");
		btnSua = new JButton("Sửa");
		btnXoaTrang = new JButton("Xóa trắng");
		pnTacvu.add(btnThem);
		pnTacvu.add(btnXoa);
		pnTacvu.add(btnSua);
		pnTacvu.add(btnXoaTrang);
		pnTacvu.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
		pnInput.add(pnTacvu);

		// tim kiem =======================================
		JPanel pnTitleTim = new JPanel();
		JLabel lblTitleTim = new JLabel("Tìm kiếm công trình");
		lblTitleTim.setFont(new Font("arial", Font.BOLD, 20));
		pnTitleTim.add(lblTitleTim);
		pnInput.add(pnTitleTim);

		// input tim ======================================
		JPanel pnTimMaLoai = new JPanel();
		pnTimMaLoai.setLayout(new BoxLayout(pnTimMaLoai, BoxLayout.X_AXIS));

		JLabel lblTimMa = new JLabel("  Tìm mã  ");
		lblTimMa.setPreferredSize(lblKC.getPreferredSize());
		txtTimMa = new JTextField();
		txtTimMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimMa.getMinimumSize().height * 200));

		JLabel lblTimLoai = new JLabel("  Tìm loại  ");
		txtTimLoai = new JTextField();
		txtTimLoai.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTimLoai.getMinimumSize().height * 200));

		pnTimMaLoai.add(lblTimMa);
		pnTimMaLoai.add(txtTimMa);
		pnTimMaLoai.add(lblTimLoai);
		pnTimMaLoai.add(txtTimLoai);
		pnInput.add(pnTimMaLoai);

		JPanel pnTimDD = new JPanel();
		pnTimDD.setLayout(new BoxLayout(pnTimDD, BoxLayout.X_AXIS));
		pnTimDD.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));

		JLabel lblTimQuan = new JLabel("  Quận  ");
		lblTimQuan.setPreferredSize(lblKC.getPreferredSize());
		cboTimQuan = new JComboBox<String>();
		cboTimQuan.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				cboTimQuan.getMinimumSize().height));

		JLabel lblTimPhuong = new JLabel("  Phường  ");
		cboTimPhuong = new JComboBox<String>();
		cboTimPhuong.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				cboTimPhuong.getMinimumSize().height));

		JLabel lblTimDuong = new JLabel("  Đường  ");
		txtTimDuong = new JTextField();
		txtTimDuong.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				txtTimDuong.getMinimumSize().height * 200));

		JLabel lblTimSoNha = new JLabel("  Số nhà  ");
		txtTimSoNha = new JTextField();
		txtTimSoNha.setMaximumSize(new Dimension(Integer.MAX_VALUE,
				txtTimSoNha.getMinimumSize().height * 200));

		pnTimDD.add(lblTimQuan);
		pnTimDD.add(cboTimQuan);
		pnTimDD.add(lblTimPhuong);
		pnTimDD.add(cboTimPhuong);
		pnTimDD.add(lblTimDuong);
		pnTimDD.add(txtTimDuong);
		pnTimDD.add(lblTimSoNha);
		pnTimDD.add(txtTimSoNha);
		pnInput.add(pnTimDD);

		JPanel pnButTim = new JPanel();
		pnButTim.setLayout(new FlowLayout(FlowLayout.LEFT));
		btnTim = new JButton("Tìm kiếm");
		pnButTim.add(btnTim);
		pnInput.add(pnButTim);

		pnMa_Ten.setPreferredSize(new Dimension(Integer.MAX_VALUE, cboQuan.getPreferredSize().height));
		pnNgay.setPreferredSize(new Dimension(Integer.MAX_VALUE, (int) (cboQuan.getPreferredSize().height * 1.5)));
		pnTimMaLoai.setPreferredSize(new Dimension(Integer.MAX_VALUE, cboQuan.getPreferredSize().height));
		
		
		// Đăng ký sự kiện
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
				if (row >= 0) {
					mauTinHienHanh = row;
					capNhatThongTinMauTin(mauTinHienHanh);
				}
			}
		});
		
		// Cập nhật thông tin mẫu tin hiện hành và các nút duyệt qua các mẫu tin
		mauTinHienHanh = -1;
		tongSoMauTin = table.getRowCount();
		if (tongSoMauTin > 0) {
			mauTinHienHanh = 0; // Khởi tạo là mẫu tin đầu tiên
			capNhatThongTinMauTin(mauTinHienHanh);
		}
				
		btnSua.addActionListener(this);
		btnThem.addActionListener(this);
		btnXoa.addActionListener(this);
		btnXoaTrang.addActionListener(this);
		cboPhuong.addActionListener(this);
		cboQuan.addActionListener(this);
		cboTrangThai.addActionListener(this);
		cboTimPhuong.addActionListener(this);
		cboTimQuan.addActionListener(this);
		btnTim.addActionListener(this);
		
		cboTimPhuong.setEditable(true);
		cboTimQuan.setEditable(true);
		btnStart.addActionListener(this);
		btnEnd.addActionListener(this);
		btnNext.addActionListener(this);
		btnPrevious.addActionListener(this);
		
		// Tạo kết nối đến database 
		try {
			ConnectDB.getInstance().connect();
			addDatabase();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	private void capNhatThongTinMauTin(int n) {
		table.setRowSelectionInterval(n, n);
		lblPage.setText(mauTinHienHanh + 1 + "/" + tongSoMauTin);
		napLopHocVaoTextfields();
	}
	
	private void napLopHocVaoTextfields() {
		int row = table.getSelectedRow();
		if (row >= 0) {
			txtMaCongTrinh.setText(table.getValueAt(row, 0).toString());
			txtTenCongTrinh.setText(table.getValueAt(row, 1).toString());
			String []s = table.getValueAt(row, 2).toString().split(" - ");
			
			txtSoNha.setText(s[0]);
			txtDuong.setText(s[1]);
			txtLoaiCongTrinh.setText(table.getValueAt(row, 3).toString());
			
			cboQuan.setSelectedItem(s[3]);
			cboPhuong.setSelectedItem(s[2]);
//			ngayKhoiCong.setDateFormatString(table.getValueAt(row, 4).toString());
//			ngayHoanThanh.setDateFormatString(table.getValueAt(row, 5).toString());
			cboTrangThai.setSelectedItem(table.getValueAt(row, 6).toString());
			String[] ngayDB = table.getValueAt(row, 4).toString().split("-");

			Calendar ca = new GregorianCalendar();
			String day = ngayDB[2];
			String month = ngayDB[1];
			String year = ngayDB[0];

			if (day.length() == 1) {
				day = "0" + day;
			}
			if (month.length() == 1) {
				month = "0" + month;
			}

			String dd = year + "-" + month + "-" + day;

			Date d;
			try {
				d = new SimpleDateFormat("yyyy-MM-dd").parse(dd);
				ngayKhoiCong.setDate(d);
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
//			txtNgayKetThuc.setText(tableBTT.getValueAt(row, 6).toString());
			String[] ngayKT = table.getValueAt(row, 5).toString().split("-");

			Calendar cakt = new GregorianCalendar();
			String daykt = ngayKT[2];
			String monthkt = ngayKT[1];
			String yearkt = ngayKT[0];

			if (daykt.length() == 1) {
				daykt = "0" + daykt;
			}
			if (monthkt.length() == 1) {
				monthkt = "0" + monthkt;
			}

			String ddkt = yearkt + "-" + monthkt + "-" + daykt;

			Date dkt;
			try {
				dkt = new SimpleDateFormat("yyyy-MM-dd").parse(ddkt);
				ngayHoanThanh.setDate(dkt);
			} catch (ParseException e1) {
				e1.printStackTrace();
			}
		}
	}
	
	//Phương thức thêm toàn bộ dử liệu công trình vào bảng
	public void addDatabase() {
		
		CongTrinh_DAO dao = new CongTrinh_DAO();
		ArrayList<CongTrinh> listCongTrinh = dao.getAlltbCongTrinh();
		//Đưa thông tin vào bảng
		listCongTrinh.forEach(v -> {
			String diaDiem = v.getDiaDiem().getSoNha() +" - "+ v.getDiaDiem().getTenDuong() +" - "+  v.getDiaDiem().getTenPhuong() +" - " + v.getDiaDiem().getTenQuan();
			Object[] row = {v.getMaCT(), v.getTenCT(), diaDiem, v.getLoaiCT(),
					v.getNgayKhoiCong(), v.getNgayHoanThanh(), v.getTrangThai()};
			tableModel.addRow(row);
		});
		
//		ArrayList<String> arrSoNha = new ArrayList<String>();
//		JcmpTimSoNha.addItem("");
//		listCongTrinh.forEach(v -> {
//			
//			if(!arrSoNha.contains(v.getDiaDiem().getSoNha()))
//			{
//				JcmpTimSoNha.addItem(v.getDiaDiem().getSoNha());
//				arrSoNha.add(v.getDiaDiem().getSoNha());
//				
//			}
//		});
//		
//		ArrayList<String> arrTenDuong = new ArrayList<String>();
//		JcmpTimDuong.addItem("");
//		listCongTrinh.forEach(v -> {	
//		
//			if(!arrTenDuong.contains(v.getDiaDiem().getTenDuong()))
//			{
//				JcmpTimDuong.addItem(v.getDiaDiem().getTenDuong());
//				arrTenDuong.add(v.getDiaDiem().getTenDuong());
//				
//			}
//		});
		
		ArrayList<String> arrTenPhuong = new ArrayList<String>();
		cboTimPhuong.addItem("");
		listCongTrinh.forEach(v -> {
		
			if(!arrTenPhuong.contains(v.getDiaDiem().getTenPhuong()))
			{
				cboTimPhuong.addItem(v.getDiaDiem().getTenPhuong());
				arrTenPhuong.add(v.getDiaDiem().getTenPhuong());
			}
		});
		
		ArrayList<String> arrTenQuan = new ArrayList<String>();
		cboTimQuan.addItem("");
		listCongTrinh.forEach(v -> {
			if(!arrTenQuan.contains(v.getDiaDiem().getTenQuan()))
			{
				cboTimQuan.addItem(v.getDiaDiem().getTenQuan());
				arrTenQuan.add(v.getDiaDiem().getTenQuan());
			}
		});
		
	}
	

	/**
	 * 
	 * @param path
	 * @param width
	 * @param height
	 * @return
	 */
	public static Icon resizeIcon(String path, int width, int height) {
		ImageIcon icon = new ImageIcon(path);
		Image img = icon.getImage();
		Image newImg = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		icon = new ImageIcon(newImg);
		return icon;

	}
	
//	public void DocDuLieuTuArrayListVaoModel() {
//		listCongtrinh = congTrinhDao.getAlltbCongTrinh();
//		for (int i = 0; i < listCongtrinh.size(); i++) {
//			CongTrinh ct = listCongtrinh.get(i);
//			tableModel.addRow(new Object[] {ct.getMaCT(), ct.getTenCT(), ct.getDiaDiem(),
//					ct.getLoaiCT(), ct.getNgayKhoiCong(), ct.getNgayHoanThanh(), ct.getTrangThai()});
//			
//		}
//	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int row = table.getSelectedRow();
		txtMaCongTrinh.setText(table.getValueAt(row, 0).toString());
		txtTenCongTrinh.setText(table.getValueAt(row, 1).toString());
		String []s = table.getValueAt(row, 2).toString().split(" - ");
		
		txtSoNha.setText(s[0]);
		txtDuong.setText(s[1]);
		txtLoaiCongTrinh.setText(table.getValueAt(row, 3).toString());
		
		cboQuan.setSelectedItem(s[3]);
		cboPhuong.setSelectedItem(s[2]);
//		ngayKhoiCong.setDateFormatString(table.getValueAt(row, 4).toString());
//		ngayHoanThanh.setDateFormatString(table.getValueAt(row, 5).toString());
		cboTrangThai.setSelectedItem(table.getValueAt(row, 6).toString());
		String[] ngayDB = table.getValueAt(row, 4).toString().split("-");

		Calendar ca = new GregorianCalendar();
		String day = ngayDB[2];
		String month = ngayDB[1];
		String year = ngayDB[0];

		if (day.length() == 1) {
			day = "0" + day;
		}
		if (month.length() == 1) {
			month = "0" + month;
		}

		String dd = year + "-" + month + "-" + day;

		Date d;
		try {
			d = new SimpleDateFormat("yyyy-MM-dd").parse(dd);
			ngayKhoiCong.setDate(d);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
//		txtNgayKetThuc.setText(tableBTT.getValueAt(row, 6).toString());
		String[] ngayKT = table.getValueAt(row, 5).toString().split("-");

		Calendar cakt = new GregorianCalendar();
		String daykt = ngayKT[2];
		String monthkt = ngayKT[1];
		String yearkt = ngayKT[0];

		if (daykt.length() == 1) {
			daykt = "0" + daykt;
		}
		if (monthkt.length() == 1) {
			monthkt = "0" + monthkt;
		}

		String ddkt = yearkt + "-" + monthkt + "-" + daykt;

		Date dkt;
		try {
			dkt = new SimpleDateFormat("yyyy-MM-dd").parse(ddkt);
			ngayHoanThanh.setDate(dkt);
		} catch (ParseException e1) {
			e1.printStackTrace();
		}
//		txtNgayCapNhat.setText(tableBTT.getValueAt(row, 8).toString());
//		String[] ngayCN = tableBTT.getValueAt(row, 8).toString().split("/");
//
//		Calendar cacn = new GregorianCalendar();
//		String daycn = ngayCN[0];
//		String monthcn = ngayCN[1];
//		String yearcn = ngayCN[2];
//
//		if (daycn.length() == 1) {
//			daycn = "0" + daycn;
//		}
//		if (monthcn.length() == 1) {
//			monthcn = "0" + monthcn;
//		}
//
//		String ddcn = yearcn + "-" + monthcn + "-" + daycn;
//
//		Date dcn;
//		try {
//			dcn = new SimpleDateFormat("yyyy-MM-dd").parse(ddcn);
//			dateNgayCapNhat.setDate(dcn);
//		} catch (ParseException e1) {
//			e1.printStackTrace();
//		}
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object ob = e.getSource();
		if(ob.equals(btnThem))
		{
			if (validData() == true) {
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				//Phat sinh ma tu dong
				CongTrinh_DAO daont = new CongTrinh_DAO();
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				
				String maCT = txtMaCongTrinh.getText().toString().trim();
				String tenCT = txtTenCongTrinh.getText();
				String loaiCT = txtLoaiCongTrinh.getText();
				
				String tenQuan = cboQuan.getSelectedItem().toString();
				String tenPhuong = cboPhuong.getSelectedItem().toString();
				String soNha = txtSoNha.getText().toString().trim();
				String tenDuong = txtDuong.getText().toString().trim();
				
				LocalDate ngayBatDau = null;
				try {
				ngayBatDau = LocalDate.of(ngayKhoiCong.getJCalendar().getYearChooser().getYear(),
				(ngayKhoiCong.getJCalendar().getMonthChooser().getMonth() + 1),
				ngayKhoiCong.getJCalendar().getDayChooser().getDay());
				} catch (DateTimeParseException e1) {
				JOptionPane.showMessageDialog(this, "Ngày bắt đầu phải theo dạng dd/MM/yyyy");
				ngayKhoiCong.setDate(null);
				ngayKhoiCong.setFocusable(true);
				}
				
				LocalDate ngayKetThuc = null;
				try {
				ngayKetThuc = LocalDate.of(ngayHoanThanh.getJCalendar().getYearChooser().getYear(),
				(ngayHoanThanh.getJCalendar().getMonthChooser().getMonth() + 1),
				ngayHoanThanh.getJCalendar().getDayChooser().getDay());
				} catch (DateTimeParseException e2) {
				JOptionPane.showMessageDialog(this, "Ngày kết thúc phải theo dạng dd/MM/yyyy");
				ngayHoanThanh.setDate(null);
				ngayHoanThanh.setFocusable(true);
				}
				String trangThai = cboTrangThai.getSelectedItem().toString().trim();
				
				CongTrinh_DAO dao = new CongTrinh_DAO();
				boolean result = dao.them(new CongTrinh(maCT, tenCT, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayBatDau, ngayKetThuc, trangThai));
				if(result==false)
				{
				JOptionPane.showMessageDialog(this, "Mã công trình bị trùng!!!");
				}
				else {
				JOptionPane.showMessageDialog(this, "Thêm thành công!!!");
				}
				tableModel.setRowCount(0);
				addDatabase();
			}
			
		}
		else if (tongSoMauTin > 0) { // Cho các nút duyệt
			if (ob.equals(btnStart))
				mauTinHienHanh = 0;
			else if (ob.equals(btnEnd))
				mauTinHienHanh = tongSoMauTin - 1;
			else if (ob.equals(btnNext) && mauTinHienHanh < tongSoMauTin - 1)
				mauTinHienHanh++;
			else if (ob.equals(btnPrevious) && mauTinHienHanh > 0)
				mauTinHienHanh--;
			capNhatThongTinMauTin(mauTinHienHanh);
		}
		
		//
		if(ob.equals(cboQuan) )
		{
			
			if(cboQuan.getSelectedItem().equals(""))
			{
				cboPhuong.removeAllItems();
				cboPhuong.setSelectedItem("");
			}
			else if(cboQuan.getSelectedItem().equals("Quận Gò Vấp"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 16,Phường 17".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 1"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường Bến Nghé,Phường Bến Thành,Phường Cầu Kho,Phường Cầu Ông Lãnh,Phường Cô Giang,Phường Đa Kao,Phường Nguyễn Cư Trinh,Phường Nguyễn Thái Bình,Phường Phạm Ngũ Lão,Phường Tân Định".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			
			else if(cboQuan.getSelectedItem().equals("Quận 2"))
			{
				cboPhuong.removeAllItems();
				
				String[] item = " ,Phường An Khánh,Phường An Lợi Đông,Phường An Phú,Phường Bình An,Phường Bình Khánh,Phường Bình Trưng Đông,Phường Bình Trưng Tây,Phường Cát Lái,Phường Thạnh Mỹ Lợi,Phường Thảo Điền,Phường Thủ Thiêm".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			if(cboQuan.getSelectedItem().equals("Quận 3"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 4"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 16,Phường 17,Phường 18".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 5"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 6"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}

			else if(cboQuan.getSelectedItem().equals("Quận 7"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường Bình Thuận,Phường Phú Mỹ,Phường Phú Thuận,Phường Tân Hưng,Phường Tân Kiểng,Phường Tân Phong,Phường Tân Phú,Phường Tân Quy,Phường Tân Thuận Đông,Phường Tân Thuận Tây".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 8"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 16".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
	
			else if(cboQuan.getSelectedItem().equals("Quận 9"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường Hiệp Phú,Phường Long Bình,Phường Long Phước,Phường Long Thạnh Mỹ,Phường Long Trường,Phường Phú Hữu,Phường Phước Bình,Phường Phước Long A,Phường Phước Long B,Phường Tân Phú,Phường Tăng Nhơn Phú A,Phường Tăng Nhơn Phú B,Phường Trường Thạnh".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			//
			else if(cboQuan.getSelectedItem().equals("Quận 10"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 11"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 16".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận 12"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường An Phú Đông,Phường Đông Hưng Thuận,Phường Hiệp Thành,Phường Tân Chánh Hiệp,Phường Tân Hưng Thuận,Phường Tân Thới Hiệp,Phường Tân Thới Nhất,Phường Thạnh Lộc,Phường Thạnh Xuân,Phường Thới An,Phường Trung Mỹ Tây".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			
			else if(cboQuan.getSelectedItem().equals("Quận Bình Tân"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường An Lạc,Phường An Lạc A,Phường Bình Hưng Hòa,Phường Bình Hưng Hoà A,Phường Bình Hưng Hoà B,Phường Bình Trị Đông,Phường Bình Trị Đông A,Phường Bình Trị Đông B,Phường Tân Tạo,Phường Tân Tạo A".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			
			else if(cboQuan.getSelectedItem().equals("Quận Bình Thạnh"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 16,Phường 17,Phường 19,Phường 21,Phường 22,Phường 24,Phường 25,Phường 26,Phường 27,Phường 28".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Phú Nhuận"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15,Phường 17".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Tân Bình"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường 1,Phường 3,Phường 4,Phường 5,Phường 6,Phường 7,Phường 8,Phường 9,Phường 10,Phường 11,Phường 12,Phường 13,Phường 14,Phường 15".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Tân Phú"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường Hiệp Tân,Phường Hoà Thạnh,Phường Phú Thạnh,Phường Phú Thọ Hoà,Phường Phú Trung,Phường Sơn Kỳ,Phường Tân Qúy,Phường Tân Sơn Nhì,Phường Tân Thành,Phường Tân Thới Hoà,Phường Tây Thạnh".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Thủ Đức"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Phường Bình Chiểu,Phường Bình Thọ,Phường Hiệp Bình Chánh,Phường Hiệp Bình Phước,Phường Linh Chiểu,Phường Linh Đông,Phường Linh Tây,Phường Linh Trung,Phường Linh Xuân,Phường Tam Bình,Phường Tam Phú,Phường Trường Thọ".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			if(cboQuan.getSelectedItem().equals("Quận Bình Chánh"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Thị trấn Tân Túc,Xã An Phú Tây,Xã Bình Chánh,Xã Bình Hưng,Xã Bình Lợi,Xã Đa Phước,Xã Hưng Long,Xã Lê Minh Xuân,Xã Phạm Văn Hai,Xã Phong Phú,Xã Quy Đức,Xã Tân Kiên,Xã Tân Nhựt,Xã Tân Quý Tây,Xã Vĩnh Lộc A,Xã Vĩnh Lộc B".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			if(cboQuan.getSelectedItem().equals("Quận Cần Giờ"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Thị trấn Cần Thạnh,Xã An Thới Đông,Xã Bình Khánh,Xã Long Hòa,Xã Lý Nhơn,Xã Tam Thôn Hiệp,Xã Thạnh An".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Củ Chi"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Thị trấn Củ Chi,Xã An Nhơn Tây,Xã An Phú,Xã Bình Mỹ,Xã Hòa Phú,Xã Nhuận Đức,Xã Phạm Văn Cội,Xã Phú Hòa Đông,Xã Phú Mỹ Hưng,Xã Phước Hiệp,Xã Phước Thạnh,Xã Phước Vĩnh An,Xã Tân An Hội,Xã Tân Phú Trung,Xã Tân Thạnh Đông,Xã Tân Thạnh Tây,Xã Tân Thông Hội,Xã Thái Mỹ,Xã Trung An,Xã Trung Lập Hạ,Xã Trung Lập Thượng".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			else if(cboQuan.getSelectedItem().equals("Quận Hóc Môn"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Thị trấn Hóc Môn,Xã Bà Điểm,Xã Đông Thạnh,Xã Nhị Bình,Xã Tân Hiệp,Xã Tân Thới Nhì,Xã Tân Xuân,Xã Thới Tam Thôn,Xã Trung Chánh,Xã Xuân Thới Đông,Xã Xuân Thới Sơn,Xã Xuân Thới Thượng".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
			

			else if(cboQuan.getSelectedItem().equals("Quận Hóc Môn"))
			{
				cboPhuong.removeAllItems();
				String[] item = " ,Thị trấn Nhà Bè,Xã Hiệp Phước,Xã Long Thới,Xã Nhơn Đức,Xã Phú Xuân,Xã Phước Kiển,Xã Phước Lộc".split(",");
				for (int i = 0; i < item.length; i++) {
					String string = item[i];
					cboPhuong.addItem(string);
				}
			}
		}
		//
		else if(ob.equals(btnXoa))
		{
			int n = JOptionPane.showConfirmDialog(this, "Bạn có muốn xóa hay không?","Xóa một dòng",JOptionPane.YES_NO_OPTION);
			if(n==JOptionPane.YES_OPTION)
			{
				String maCongTrinh = txtMaCongTrinh.getText().toString();
				CongTrinh_DAO dao = new CongTrinh_DAO();
				boolean result = dao.XoaCongTrinhLaoDong(maCongTrinh);
				if(result==false)
				{
					JOptionPane.showMessageDialog(this, "Xóa thất bại!!!");
				}
				else {
					JOptionPane.showMessageDialog(this, "Xóa thành công!!!");
				}
				tableModel.setRowCount(0);
				addDatabase();
			}
			
		}
		//
		else if(ob.equals(btnXoaTrang))
		{
			//setText ma nha tro moi khong trung vao txtMaNhaTro
//			NhaTro_Dao daont = new NhaTro_Dao();
//			
//			List<NhaTro> list = daont.layTatCaBang();
//			list.forEach(v -> {
//				String[] ma1 = v.getMaTro().split("_");			
//				
//				if(max<=Integer.parseInt(ma1[1].toString().trim()))
//				{
//					max = Integer.parseInt(ma1[1].toString().trim());
//					max = max+1;
//				}
//			});
//			
//			String maTro = null;
//			if(max<10)
//			{
//				maTro = "NT_0000"+max;
//			}
//			else if(max<100)
//			{
//				maTro = "NT_000"+max;
//			}
//			else if(max<1000)
//			{
//				maTro = "NT_00"+max;
//			}
//			else if(max<10000)
//			{
//				maTro = "NT_"+max;
//			}
//			else if(max<100000)
//			{
//				maTro = "NT_"+max;
//			}
			txtMaCongTrinh.setText("");
			txtTenCongTrinh.setText("");
			txtLoaiCongTrinh.setText("");
			cboTrangThai.setSelectedItem("");
			cboQuan.setSelectedItem("");
			cboPhuong.setSelectedItem("");
			txtSoNha.setText("");
			txtDuong.setText("");
			ngayKhoiCong.setDate(null);
			ngayHoanThanh.setDate(null);
			
			tableModel.setRowCount(0);
			txtTimDuong.setText("");
			cboTimPhuong.setSelectedItem("");
			cboTimQuan.setSelectedItem("");
			txtTimSoNha.setText("");
			txtMaCongTrinh.requestFocus();
			addDatabase();
		}
		//
		else if(ob.equals(btnSua))
		{
			
			if(validData() == true) {
				CongTrinh_DAO daoCongTrinh= new CongTrinh_DAO();
				String maCT = txtMaCongTrinh.getText();
				String tenCT = txtTenCongTrinh.getText();
				String loaiCT = txtLoaiCongTrinh.getText();
				String tenQuan = cboQuan.getSelectedItem().toString();
				String tenPhuong = cboPhuong.getSelectedItem().toString();
				String soNha = txtSoNha.getText().toString().trim();
				String tenDuong = txtDuong.getText().toString().trim();
				
				LocalDate ngayBatDau = null;
				try {
					ngayBatDau = LocalDate.of(ngayKhoiCong.getJCalendar().getYearChooser().getYear(),
							(ngayKhoiCong.getJCalendar().getMonthChooser().getMonth() + 1),
							ngayKhoiCong.getJCalendar().getDayChooser().getDay());
				} catch (DateTimeParseException e1) {
					JOptionPane.showMessageDialog(this, "Ngày bắt đầu phải theo dạng dd/MM/yyyy");
					ngayKhoiCong.setDate(null);
					ngayKhoiCong.setFocusable(true);
				}
				
				LocalDate ngayKetThuc = null;
				try {
					ngayKetThuc = LocalDate.of(ngayHoanThanh.getJCalendar().getYearChooser().getYear(),
							(ngayHoanThanh.getJCalendar().getMonthChooser().getMonth() + 1),
							ngayHoanThanh.getJCalendar().getDayChooser().getDay());
				} catch (DateTimeParseException e2) {
					JOptionPane.showMessageDialog(this, "Ngày kết thúc phải theo dạng dd/MM/yyyy");
					ngayHoanThanh.setDate(null);
					ngayHoanThanh.setFocusable(true);
				}
				String trangThai = cboTrangThai.getSelectedItem().toString();
				
				CongTrinh congTrinh = new CongTrinh(maCT, tenCT, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayBatDau, ngayKetThuc, trangThai);
				
				if(daoCongTrinh.CapNhatCongTrinhLaoDong(congTrinh)==true)
				{
					JOptionPane.showMessageDialog(this, "Sửa thành công!!");
					tableModel.setRowCount(0);
					addDatabase();
				}
				else {
					JOptionPane.showMessageDialog(this, "Sửa thất bại!!");
				}
			}
			
		}
		else if(ob.equals(btnTim)) {
			// Tìm theo mã
			if(!(txtTimMa.getText().equals("")) && txtTimLoai.getText().equals("") && txtTimSoNha.getText().equals("") && txtTimDuong.getText().equals("") && cboTimPhuong.getSelectedItem().equals("") && cboTimQuan.getSelectedItem().equals(""))
			{
				if (txtTimMa.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String ma = txtTimMa.getText().toString().trim();
					if (ct_dao.layCongTrinhTheoMa(ma) != null) {
						tableModel.setRowCount(0);
						CongTrinh congTrinh = ct_dao.layCongTrinhTheoMa(ma);
						String maCT = congTrinh.getMaCT();
						String tenCT = congTrinh.getTenCT();
						String loaiCT = congTrinh.getLoaiCT();
						DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
						String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
						String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
						String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
						String trangThai = congTrinh.getTrangThai();
						String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
						tableModel.addRow(row);
						
					}else if(ct_dao.layCongTrinhTheoMa(ma) == null) {
						txtTimMa.setText("");
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				}
			}
			//Tìm theo loại
			if(txtTimMa.getText().equals("") && !(txtTimLoai.getText().equals("")) && txtTimSoNha.getText().equals("") && txtTimDuong.getText().equals("") && cboTimPhuong.getSelectedItem().equals("") && cboTimQuan.getSelectedItem().equals(""))
			{
				if(txtTimLoai.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String loai = txtTimLoai.getText().toString().trim();
					if (ct_dao.layCongTrinhTheoLoai(loai) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoLoai(loai).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoLoai(loai) == null) {
						txtTimLoai.setText("");
						JOptionPane.showMessageDialog(this, "Không có loại cần tìm");
					}
				
				}
			}
			//Tìm theo số nhà
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && !(txtTimSoNha.getText().equals("")) && txtTimDuong.getText().equals("") && cboTimPhuong.getSelectedItem().equals("") && cboTimQuan.getSelectedItem().equals(""))
			{
				if(txtTimSoNha.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String sonha = txtTimSoNha.getText().toString().trim();
					if (ct_dao.layCongTrinhTheoSoNha(sonha) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoSoNha(sonha).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoSoNha(sonha) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				
				}
			}
			//Tìm theo tên đường
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && txtTimSoNha.getText().equals("") && !(txtTimDuong.getText().equals("")) && cboTimPhuong.getSelectedItem().equals("") && cboTimQuan.getSelectedItem().equals(""))
			{
				if(txtTimDuong.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String tenDuong = txtTimDuong.getText().toString().trim();
					if (ct_dao.layCongTrinhTheoTenDuong(tenDuong) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoTenDuong(tenDuong).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoTenDuong(tenDuong) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				
				}
			}
			//tìm theo tên phường
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && txtTimSoNha.getText().equals("") && txtTimDuong.getText().equals("") && !(cboTimPhuong.getSelectedItem().equals("")) && cboTimQuan.getSelectedItem().equals(""))
			{
				if(cboTimPhuong.getSelectedItem().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String tenPhuong = cboTimPhuong.getSelectedItem().toString().trim();
					if (ct_dao.layCongTrinhTheoPhuong(tenPhuong) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoPhuong(tenPhuong).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoPhuong(tenPhuong) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				
				}
			}
			//Tìm theo tên quận
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && txtTimSoNha.getText().equals("") && txtTimDuong.getText().equals("") && cboTimPhuong.getSelectedItem().equals("") && !(cboTimQuan.getSelectedItem().equals("")))
			{
				if(cboTimQuan.getSelectedItem().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String tenQuan = cboTimQuan.getSelectedItem().toString().trim();
					if (ct_dao.layCongTrinhTheoQuan(tenQuan) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoQuan(tenQuan).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoQuan(tenQuan) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				
				}
			}
			//Tìm số nhà và tên đường
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && !(txtTimSoNha.getText().equals("")) && !(txtTimDuong.getText().equals("")) && cboTimPhuong.getSelectedItem().equals("") && cboTimQuan.getSelectedItem().equals(""))
			{
				if(txtTimSoNha.getText().toString().trim() != "" && txtTimDuong.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String sonha = txtTimSoNha.getText().toString().trim();
					String duong = txtTimDuong.getText().toString().trim();
					if (ct_dao.layCongTrinhTheoSoNhaTenDuong(sonha, duong) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoSoNhaTenDuong(sonha, duong).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoSoNhaTenDuong(sonha, duong) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}
				
				}
			}
			//Tìm theo phường và quận
			if(txtTimMa.getText().equals("") && txtTimLoai.getText().equals("") && txtTimSoNha.getText().equals("") && txtTimDuong.getText().equals("") && !(cboTimPhuong.getSelectedItem().equals("")) && !(cboTimQuan.getSelectedItem().equals("")))
			{
				if(cboTimPhuong.getSelectedItem().toString().trim() != "" && cboTimQuan.getSelectedItem().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String quan = cboTimQuan.getSelectedItem().toString().trim();
					String phuong = cboTimPhuong.getSelectedItem().toString().trim();
					if (ct_dao.layCongTrinhTheoPhuongQuan(phuong, quan) != null) {
						tableModel.setRowCount(0);
						
						ct_dao.layCongTrinhTheoPhuongQuan(phuong, quan).forEach(congTrinh -> {
							String maCT = congTrinh.getMaCT();
							String tenCT = congTrinh.getTenCT();
							String loaiCT = congTrinh.getLoaiCT();
							DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
							String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
							String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
							String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
							String trangThai = congTrinh.getTrangThai();
							String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
							tableModel.addRow(row);						
						});
						
					}else if(ct_dao.layCongTrinhTheoPhuongQuan(phuong, quan) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}	
				}
			}
			//Tìm theo số nhà, tên đường, tên phường, tên quận
			if(!(txtTimMa.getText().equals("")) && txtTimLoai.getText().equals("") && !(txtTimSoNha.getText().equals("")) && !(txtTimDuong.getText().equals("")) && !(cboTimPhuong.getSelectedItem().equals("")) && !(cboTimQuan.getSelectedItem().equals("")))
			{
				if(cboTimPhuong.getSelectedItem().toString().trim() != "" && cboTimQuan.getSelectedItem().toString().trim() != "" && txtTimSoNha.getText().toString().trim() != "" && txtTimDuong.getText().toString().trim() != "") {
					CongTrinh_DAO ct_dao = new CongTrinh_DAO();
					String sonha = txtTimSoNha.getText().toString().trim();
					String duong = txtTimDuong.getText().toString().trim();
					
					String quan = cboTimQuan.getSelectedItem().toString().trim();
					String phuong = cboTimPhuong.getSelectedItem().toString().trim();
					if (ct_dao.layCongTrinhTheoDiaDiem(sonha, duong, phuong, quan) != null) {
						tableModel.setRowCount(0);
						CongTrinh congTrinh = ct_dao.layCongTrinhTheoDiaDiem(sonha, duong, phuong, quan);
						String maCT = congTrinh.getMaCT();
						String tenCT = congTrinh.getTenCT();
						String loaiCT = congTrinh.getLoaiCT();
						DateTimeFormatter df = DateTimeFormatter.ofPattern("dd/mm/yyyy");
						String ngayKhoiCong = congTrinh.getNgayKhoiCong().getDayOfMonth() + "/" + congTrinh.getNgayKhoiCong().getMonthValue() + "/" +congTrinh.getNgayKhoiCong().getYear();
						String ngayHoanThanh = congTrinh.getNgayHoanThanh().getDayOfMonth() + "/" + congTrinh.getNgayHoanThanh().getMonthValue() + "/" +congTrinh.getNgayHoanThanh().getYear();
						String diaDiem = congTrinh.getDiaDiem().getSoNha() + " - " + congTrinh.getDiaDiem().getTenDuong() + " - " + congTrinh.getDiaDiem().getTenPhuong() + " - " + congTrinh.getDiaDiem().getTenQuan();			
						String trangThai = congTrinh.getTrangThai();
						String []row = {maCT, tenCT,diaDiem, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai};
						tableModel.addRow(row);
						
					}else if(ct_dao.layCongTrinhTheoDiaDiem(sonha, duong, phuong, quan) == null) {
						JOptionPane.showMessageDialog(this, "Không có công trình cần tìm");
					}	
				}
			}
			
			///
		}
		//end btn tìm
	}
	private boolean validData() {
		String maCT = txtMaCongTrinh.getText().trim();
		String tenCT = txtTenCongTrinh.getText().trim();
		String loaiCT = txtLoaiCongTrinh.getText().trim();
		String soNha = txtSoNha.getText().trim();
		String duong = txtDuong.getText().trim();
			
		if(maCT.length()==0) {
			JOptionPane.showMessageDialog(this, "Mã công trình không được bỏ trống");
			txtMaCongTrinh.requestFocus();
			return false;
		}
		
		if(!(maCT.matches("CT[0-9]{2,5}"))) {
			JOptionPane.showMessageDialog(this, "Mã công trình phải theo mẫu CT00000");
			txtMaCongTrinh.requestFocus();
			return false;
		}
		if(!(tenCT.length()>0)) {
			JOptionPane.showMessageDialog(this, "Tên công trình không được bỏ trống");
			txtTenCongTrinh.requestFocus();
			return false;
		}
//		if(!(tenCT.matches("[\\p{Lu}[A-Z]][\\p{L}[a-z]]*( [\\p{Lu}[A-Z]][\\p{L}[a-z]]*)*"))) {
//			JOptionPane.showMessageDialog(this, "Tên công trình không phù hợp");
//			txtTenCongTrinh.requestFocus();
//			return false;
//		}
		if(cboQuan.getSelectedItem().toString().equals(" "))
		{
			JOptionPane.showMessageDialog(this, "Bạn chưa nhập tên quận!!!");
			return false;
		}
		if(cboPhuong.getSelectedItem().toString().equals(" "))
		{
			JOptionPane.showMessageDialog(this, "Bạn chưa nhập tên phường!!!");
			return false;
		}
		if(!(soNha.length()>0)) {
			JOptionPane.showMessageDialog(this, "Số nhà không được bỏ trống");
			txtSoNha.requestFocus();
			return false;
		}
		if(!(soNha.matches("[0-9a-zA-Z/-]+"))) {
			JOptionPane.showMessageDialog(this, "Số nhà không phù hợp");
			txtSoNha.requestFocus();
			return false;
		}
		if(!(duong.length()>0)) {
			JOptionPane.showMessageDialog(this, "Tên đường không được bỏ trống");
			txtDuong.requestFocus();
			return false;
		}
		if(!(duong.matches("[\\p{Lu}[A-Z]][\\p{L}[a-z]]*( [\\p{Lu}[A-Z]][\\p{L}[a-z]]*)*"))) {
			JOptionPane.showMessageDialog(this, "Tên đường không phù hợp");
			txtDuong.requestFocus();
			return false;
		}
		if(cboTrangThai.getSelectedItem().toString().equals(" "))
		{
			JOptionPane.showMessageDialog(this, "Bạn chưa nhập trạng thái!!!");
			return false;
		}
		if (ngayKhoiCong.getDate() == null) {
			JOptionPane.showMessageDialog(this, "Chưa nhập ngày khởi công");
			ngayKhoiCong.grabFocus();
			return false;
		}
		if (ngayHoanThanh.getDate() == null) {
			JOptionPane.showMessageDialog(this, "Chưa nhập ngày hoàn thành");
			ngayHoanThanh.grabFocus();
			return false;
		}		
		return true;
	}
		
}
