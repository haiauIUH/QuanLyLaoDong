package gui;

import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.CompoundBorder;
import javax.swing.table.DefaultTableModel;

public class CongViecGui extends JPanel {
    private JTextField txtMa;
    private JTextField txtTen;
    private JComboBox<String> cboTrinhDo;

    private JButton btnThem;
    private JButton btnXoa;
    private JButton btnSua;
    private JButton btnXoaTrang;
    private JButton btnTim;

    private JTextField txtTimTen;

    private JTable table;
    private DefaultTableModel tableModel;

    public CongViecGui() {

        this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

        JPanel pnTitle = new JPanel();
        JLabel lblTitle = new JLabel("CONG VIEC");
        lblTitle.setFont(new Font("arial", Font.BOLD, 20));
        pnTitle.add(lblTitle);
        this.add(pnTitle);

        JPanel pnCenter = new JPanel();
        pnCenter.setLayout(new BoxLayout(pnCenter, BoxLayout.Y_AXIS));
        pnCenter.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        this.add(pnCenter);

        // ===============
        // input
        JPanel pnInput = new JPanel();
        pnInput.setLayout(new BoxLayout(pnInput, BoxLayout.X_AXIS));
        pnInput.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        JLabel lblMa = new JLabel("  Ma lao dong  ");
        txtMa = new JTextField();
        txtMa.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMa.getMinimumSize().height));
        JLabel lblTen = new JLabel("  Ten lao dong  ");
        txtTen = new JTextField();
        txtTen.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtTen.getMinimumSize().height));
        JLabel lblTrinhDo = new JLabel("  Trinh do  ");
        cboTrinhDo = new JComboBox<>();
        cboTrinhDo.setMaximumSize(new Dimension(Integer.MAX_VALUE, cboTrinhDo.getMinimumSize().height));
        pnInput.add(lblMa);
        pnInput.add(txtMa);
        pnInput.add(lblTen);
        pnInput.add(txtTen);
        pnInput.add(lblTrinhDo);
        pnInput.add(cboTrinhDo);
        pnCenter.add(pnInput);

        String[] header = "Ma cong viec;Ten cong viec;Trinh do".split(";");
        tableModel = new DefaultTableModel(header, 0);
        table = new JTable(tableModel);
        table.getTableHeader().setDefaultRenderer(new PhanCongGui.SimpleHeaderRenderer());
        pnCenter.add(new JScrollPane(table));

        JPanel pnTacVu = new JPanel();
        pnTacVu.setBorder(new CompoundBorder(
                BorderFactory.createEmptyBorder(10, 5, 10, 5),
                BorderFactory.createTitledBorder("Tac vu")));
        pnCenter.add(pnTacVu);
        btnThem = new JButton("Them");
        btnXoa = new JButton("Xoa");
        btnSua = new JButton("Sua");
        btnXoaTrang = new JButton("Xoa trang");
        btnTim = new JButton("Tim");
        txtTimTen = new JTextField(20);
        pnTacVu.add(btnThem);
        pnTacVu.add(btnXoa);
        pnTacVu.add(btnSua);
        pnTacVu.add(btnXoaTrang);
        pnTacVu.add(txtTimTen);
        pnTacVu.add(btnTim);

    }

}
