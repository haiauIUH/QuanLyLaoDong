package gui;

import java.awt.BorderLayout;
import java.io.IOException;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import connectDB.ConnectDB;

public class MainGui extends JFrame {

    private static final long serialVersionUID = 1L;

    public static JPanel pnCenter = new JPanel();
    public static CongTrinhGui pnCongTrinh = new CongTrinhGui();
    public static LaoDongGui pnLaoDong = new LaoDongGui();
    public static NhanVienGui pnNhanVien = new NhanVienGui();
    public static PhanCongGui pnPhanCong = new PhanCongGui();
    public static CongViecGui pnCongViec = new CongViecGui();

    public MainGui() {
        this.setSize(1400, 700);
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        try {
            createGui();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void createGui() throws IOException {
        JPanel pnMain = new JPanel();
        pnMain.setLayout(new BorderLayout());
        this.getContentPane().add(pnMain);

        MenuGui pnMenu = new MenuGui();
        pnMain.add(pnMenu, BorderLayout.WEST);

        pnCenter.setLayout(new BorderLayout());

        pnCenter.add(pnCongViec);
        pnMain.add(pnCenter);

    }

    public static void main(String[] args) {

        new MainGui().setVisible(true);

    }
}
