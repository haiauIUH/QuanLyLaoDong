package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

public class DoiMatKhauGui extends JFrame {

    private JPasswordField txtMKCu;
    private JPasswordField txtMKMoi;
    private JPasswordField txtXacNhanMK;
    private JButton btnDoi;
    private JButton btnHuy;

    public DoiMatKhauGui() {
        setSize(400, 250);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Doi mat khau");
        setResizable(false);

        JPanel pnMain = new JPanel();
        pnMain.setLayout(new BorderLayout());
        this.getContentPane().add(pnMain);

        JLabel lblImg = new JLabel(CongTrinhGui.resizeIcon("images/password.png", 50, 50));
        lblImg.setBorder(BorderFactory.createEmptyBorder(20, 0, 0, 0));
        pnMain.add(lblImg, BorderLayout.NORTH);

        // ===========
        JPanel pnCenter = new JPanel();
        pnCenter.setLayout(new BoxLayout(pnCenter, BoxLayout.Y_AXIS));
        pnCenter.setBorder(BorderFactory.createEmptyBorder(10, 30, 10, 30));
        pnMain.add(pnCenter);

        // =========
        JPanel pnPwOld = new JPanel();
        pnPwOld.setLayout(new BoxLayout(pnPwOld, BoxLayout.X_AXIS));
        pnPwOld.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel lblPwOld = new JLabel("Mat khau cu  ");
        txtMKCu = new JPasswordField();
        txtMKCu.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMKCu.getMinimumSize().height));
        pnPwOld.add(lblPwOld);
        pnPwOld.add(txtMKCu);
        pnCenter.add(pnPwOld);

        // ============
        JPanel pnPwNew = new JPanel();
        pnPwNew.setLayout(new BoxLayout(pnPwNew, BoxLayout.X_AXIS));
        pnPwNew.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel lblPwNew = new JLabel("Mat khau moi  ");
        txtMKMoi = new JPasswordField();
        txtMKMoi.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtMKMoi.getMinimumSize().height));
        pnPwNew.add(lblPwNew);
        pnPwNew.add(txtMKMoi);
        pnCenter.add(pnPwNew);

        // ===============
        JPanel pnPwCf = new JPanel();
        pnPwCf.setLayout(new BoxLayout(pnPwCf, BoxLayout.X_AXIS));
        pnPwCf.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        JLabel lblPwCf = new JLabel("Xac nhan mat khau  ");
        txtXacNhanMK = new JPasswordField(20);
        txtXacNhanMK.setMaximumSize(new Dimension(Integer.MAX_VALUE, txtXacNhanMK.getMinimumSize().height));
        pnPwCf.add(lblPwCf);
        pnPwCf.add(txtXacNhanMK);
        pnCenter.add(pnPwCf);

        lblPwOld.setPreferredSize(lblPwCf.getPreferredSize());
        lblPwNew.setPreferredSize(lblPwCf.getPreferredSize());

        JPanel pnBtn = new JPanel();
        pnBtn.setLayout(new BoxLayout(pnBtn, BoxLayout.X_AXIS));
        pnBtn.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
        btnDoi = new JButton("Doi");
        JLabel lblTemp = new JLabel("         ");
        btnHuy = new JButton("Huy");
        pnBtn.add(btnDoi);
        pnBtn.add(lblTemp);
        pnBtn.add(btnHuy);
        pnCenter.add(pnBtn);

    }
}
