package entity;

public class DiaDiem {
	private String soNha;
	private String tenDuong;
	private String tenPhuong;
	private String tenQuan;
	public DiaDiem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public DiaDiem(String soNha, String tenDuong, String tenPhuong, String tenQuan) {
		super();
		this.soNha = soNha;
		this.tenDuong = tenDuong;
		this.tenPhuong = tenPhuong;
		this.tenQuan = tenQuan;
	}
	public String getSoNha() {
		return soNha;
	}
	public void setSoNha(String soNha) {
		this.soNha = soNha;
	}
	public String getTenDuong() {
		return tenDuong;
	}
	public void setTenDuong(String tenDuong) {
		this.tenDuong = tenDuong;
	}
	public String getTenPhuong() {
		return tenPhuong;
	}
	public void setTenPhuong(String tenPhuong) {
		this.tenPhuong = tenPhuong;
	}
	public String getTenQuan() {
		return tenQuan;
	}
	public void setTenQuan(String tenQuan) {
		this.tenQuan = tenQuan;
	}
	@Override
	public String toString() {
		return "DiaDiem [soNha=" + soNha + ", tenDuong=" + tenDuong + ", tenPhuong=" + tenPhuong + ", tenQuan="
				+ tenQuan + "]";
	}
		
}
