package entity;

import java.sql.Date;
import java.time.LocalDate;

public class CongTrinh {
	private String maCT;
	private String tenCT;
	private DiaDiem diaDiem;
	private String loaiCT;
	private LocalDate ngayKhoiCong;
	private LocalDate ngayHoanThanh;
	private String trangThai;
	
	public CongTrinh() {
		this("", "", null, "", null, null, "");
	}
	
	public CongTrinh(String maCT) {
		this.maCT = maCT;
	}

	public CongTrinh(String maCT, String tenCT, DiaDiem diaDiem, String loaiCT, LocalDate ngayKhoiCong,
			LocalDate ngayHoanThanh, String trangThai) {
		super();
		this.maCT = maCT;
		this.tenCT = tenCT;
		this.diaDiem = diaDiem;
		this.loaiCT = loaiCT;
		this.ngayKhoiCong = ngayKhoiCong;
		this.ngayHoanThanh = ngayHoanThanh;
		this.trangThai = trangThai;
	}

	public String getMaCT() {
		return maCT;
	}

	public void setMaCT(String maCT) {
		this.maCT = maCT;
	}

	public String getTenCT() {
		return tenCT;
	}

	public void setTenCT(String tenCT) {
		this.tenCT = tenCT;
	}

	public DiaDiem getDiaDiem() {
		return diaDiem;
	}

	public void setDiaDiem(DiaDiem diaDiem) {
		this.diaDiem = diaDiem;
	}

	public String getLoaiCT() {
		return loaiCT;
	}

	public void setLoaiCT(String loaiCT) {
		this.loaiCT = loaiCT;
	}

	public LocalDate getNgayKhoiCong() {
		return ngayKhoiCong;
	}

	public void setNgayKhoiCong(LocalDate ngayKhoiCong) {
		this.ngayKhoiCong = ngayKhoiCong;
	}

	public LocalDate getNgayHoanThanh() {
		return ngayHoanThanh;
	}

	public void setNgayHoanThanh(LocalDate ngayHoanThanh) {
		this.ngayHoanThanh = ngayHoanThanh;
	}

	public String getTrangThai() {
		return trangThai;
	}

	public void setTrangThai(String trangThai) {
		this.trangThai = trangThai;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((maCT == null) ? 0 : maCT.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CongTrinh other = (CongTrinh) obj;
		if (maCT == null) {
			if (other.maCT != null)
				return false;
		} else if (!maCT.equals(other.maCT))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "CongTrinh [maCT=" + maCT + ", tenCT=" + tenCT + ", diaDiem=" + diaDiem + ", loaiCT=" + loaiCT
				+ ", ngayKhoiCong=" + ngayKhoiCong + ", ngayHoanThanh=" + ngayHoanThanh + ", trangThai=" + trangThai
				+ "]";
	}
	
}
