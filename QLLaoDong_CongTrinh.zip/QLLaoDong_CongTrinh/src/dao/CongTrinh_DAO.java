package dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;


import connectDB.ConnectDB;
import entity.CongTrinh;
import entity.DiaDiem;

public class CongTrinh_DAO {
	private ArrayList<CongTrinh> listCongTrinh;
	
	public CongTrinh_DAO() {
		listCongTrinh = new ArrayList<CongTrinh>();

    	try {
			ConnectDB.getInstance().connect();
			System.out.println("successful connection !");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<CongTrinh> getAlltbCongTrinh() {
		ArrayList<CongTrinh> listCT = new ArrayList<CongTrinh>();
		try {
			ConnectDB.getInstance();
			Connection con = ConnectDB.getConnection();
			
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT";
			Statement statement = con.createStatement();
			
			ResultSet resultSet = statement.executeQuery(sql);
			while (resultSet.next()) {
				String maCT = resultSet.getString("maCT");
				String tenCT = resultSet.getString("tenCT");
				String loaiCT = resultSet.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(resultSet.getDate("ngayKhoiCong").toLocalDate().getYear(),
						resultSet.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), resultSet.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(resultSet.getDate("ngayHoanThanh").toLocalDate().getYear(),
						resultSet.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), resultSet.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String trangThai = resultSet.getString("trangThai");
				
				String soNha = resultSet.getString("soNha");
				String tenDuong = resultSet.getString("tenDuong");
				String tenPhuong = resultSet.getString("tenPhuong");
				String tenQuan = resultSet.getString("tenQuan");
				
				CongTrinh ct = new CongTrinh(maCT, tenCT, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				listCT.add(ct);
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return listCT;
	}
	
	public boolean them(CongTrinh congTrinh)
	{
		List<CongTrinh> listNT = getAlltbCongTrinh();
		if(listNT.contains(congTrinh))
		{
			return false;
		}
		else
		{
			themCongTrinh(congTrinh);
			themDiaChi(congTrinh);
		}	
		
		return true;
	}
	
	private boolean themCongTrinh(CongTrinh congTrinh)
	{
			Connection con = ConnectDB.getInstance().getConnection();
			PreparedStatement stmt = null;
			int n =0;
			 
			try {
				stmt = con.prepareStatement("insert CongTrinh values(?,?,?,?,?,?)");
				stmt.setString(1, congTrinh.getMaCT());
				stmt.setString(2, congTrinh.getTenCT());
				stmt.setString(3, congTrinh.getLoaiCT());			
				stmt.setDate(4, Date.valueOf(congTrinh.getNgayKhoiCong()));
				stmt.setDate(5, Date.valueOf(congTrinh.getNgayHoanThanh()));
				stmt.setString(6, congTrinh.getTrangThai());
				
				n=stmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
			return n>0;
	}
	
	private boolean themDiaChi(CongTrinh congTrinh)
	{
			Connection con = ConnectDB.getInstance().getConnection();
			PreparedStatement stmt = null;
			int n =0;
			 
			try {
				stmt = con.prepareStatement("insert DiaDiem values(?,?,?,?,?)");
				stmt.setString(1, congTrinh.getMaCT());
				stmt.setString(2, congTrinh.getDiaDiem().getSoNha());
				stmt.setString(3, congTrinh.getDiaDiem().getTenDuong());
				stmt.setString(4, congTrinh.getDiaDiem().getTenPhuong());
				stmt.setString(5, congTrinh.getDiaDiem().getTenQuan());
				n = stmt.executeUpdate();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
		
		return n>0;
	}
	
	private boolean XoaCongTrinh(String maCongTrinh)
	{
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n = 0;
		
		try {
			stmt = con.prepareStatement(" Delete from [QuanLiLaoDong].[dbo].[CongTrinh] where [maCT] =?");
			stmt.setString(1, maCongTrinh);
			n = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n>0;
	}
	
	private boolean XoaDiaChi(String maDiaChi)
	{
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n =0;
		
		try {
			stmt = con.prepareStatement("Delete from [QuanLiLaoDong].[dbo].[DiaDiem] where [maCT] =?");
			stmt.setString(1, maDiaChi);
			n = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return n>0;
	}
	
	public boolean XoaCongTrinhLaoDong(String maCT)
	{
		boolean flag1, flag2;
		flag2 = XoaDiaChi(maCT);
		flag1 = XoaCongTrinh(maCT);
		;
		if(flag1==true && flag2==true)
		{
			return true;
		}
		else
			return false;
	}
	
	public boolean CapNhatCongTrinhLaoDong(CongTrinh congTrinh)
	{
		CapNhatCongTrinh(congTrinh);
		CapNhatDiaChi(congTrinh);
		return true;
	}
	
	private boolean CapNhatCongTrinh(CongTrinh congTrinh)
	{
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt  = null;
		int n=0;
		
		try {
			stmt = con.prepareStatement("Update CongTrinh set tenCT = ?, loaiCT= ?, ngayKhoiCong=?, ngayHoanThanh=?, trangThai=? where maCT = ?");
			stmt.setString(1, congTrinh.getTenCT());
			stmt.setString(2, congTrinh.getLoaiCT());
			stmt.setDate(3, Date.valueOf(congTrinh.getNgayKhoiCong()));
			stmt.setDate(4, Date.valueOf(congTrinh.getNgayHoanThanh()));
			stmt.setString(5, congTrinh.getTrangThai());
			stmt.setString(6, congTrinh.getMaCT());
			n = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n>0;
	}
	
	public boolean CapNhatDiaChi(CongTrinh congTrinh)
	{
		Connection con = ConnectDB.getInstance().getConnection();
		PreparedStatement stmt = null;
		int n =0;
		
		try {
			stmt = con.prepareStatement("Update DiaDiem set soNha=?, tenDuong = ?, tenPhuong =?, tenQuan=? where maCT=?");
			stmt.setString(1, congTrinh.getDiaDiem().getSoNha());
			stmt.setString(2, congTrinh.getDiaDiem().getTenDuong());
			stmt.setString(3, congTrinh.getDiaDiem().getTenPhuong());
			stmt.setString(4, congTrinh.getDiaDiem().getTenQuan());
			stmt.setString(5, congTrinh.getMaCT());
			n = stmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return n>0;
	}
	
	//Tìm kiếm
	public CongTrinh layCongTrinhTheoMa(String ma)
	{
		
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where ct.maCT = "+"'"+ma+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				return congTrinh;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return null;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoLoai(String loai)
	{
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where ct.loaiCT = "+"N'"+loai+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return dsCongTrinh;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoQuan(String quan) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where tenQuan = "+"N'"+quan+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoPhuong(String phuong) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where tenPhuong = "+"N'"+phuong+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoTenDuong(String duong) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where tenDuong = "+"N'"+duong+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoSoNha(String nha) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where soNha = "+"N'"+nha+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	///
	public CongTrinh layCongTrinhTheoDiaDiem(String sonha, String duong, String phuong,String quan) {
		Statement statement=null;
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from CongTrinh ct join DiaDiem dd on ct.maCT = dd.maCT where soNha =N'"+ sonha +"' and tenDuong = N'"+duong+"' and tenPhuong = N'"+phuong+"' and tenQuan = N'"+quan+"'";
			statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				return congTrinh;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			try {
				statement.close();
			} catch (SQLException e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		
	return null;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoPhuongQuan(String phuong, String quan) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where tenPhuong = "+"N'"+phuong+"' and  tenQuan ="+"N'"+quan+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	public ArrayList<CongTrinh> layCongTrinhTheoSoNhaTenDuong(String nha, String duong) {
		ArrayList<CongTrinh> dsCongTrinh = new ArrayList<CongTrinh>();
		try {
			Connection con = ConnectDB.getInstance().getConnection();
			String sql = "select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where soNha = "+"N'"+nha+"' and  tenDuong ="+"N'"+duong+"'";
			Statement statement = con.createStatement();
			ResultSet rs = statement.executeQuery(sql);
			while(rs.next())
			{
				String maCT = rs.getString("maCT");
				String tenCt = rs.getString("tenCT");
				String loaiCT = rs.getString("loaiCT");
				LocalDate ngayKhoiCong = LocalDate.of(rs.getDate("ngayKhoiCong").toLocalDate().getYear(),
						rs.getDate("ngayKhoiCong").toLocalDate().getMonthValue(), rs.getDate("ngayKhoiCong").toLocalDate().getDayOfMonth());
				LocalDate ngayHoanThanh = LocalDate.of(rs.getDate("ngayHoanThanh").toLocalDate().getYear(),
						rs.getDate("ngayHoanThanh").toLocalDate().getMonthValue(), rs.getDate("ngayHoanThanh").toLocalDate().getDayOfMonth());
				String soNha= rs.getString("soNha");
				String  tenDuong= rs.getString("tenDuong");
				String tenPhuong= rs.getString("tenPhuong");
				String  tenQuan = rs.getString("tenQuan");
				String trangThai = rs.getString("trangThai");
				CongTrinh congTrinh = new CongTrinh(maCT, tenCt, new DiaDiem(soNha, tenDuong, tenPhuong, tenQuan), loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai);
				dsCongTrinh.add(congTrinh);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	return dsCongTrinh;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
