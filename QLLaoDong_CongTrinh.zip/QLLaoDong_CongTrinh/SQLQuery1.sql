﻿USE QuanLiLaoDong
GO

/*Tạo bảng Công trình*/
CREATE TABLE CongTrinh
(
	maCT nchar(20) primary key not null,
	tenCT nvarchar(50) not null,
	loaiCT nvarchar(50) not null,
	ngayKhoiCong date not null,
	ngayHoanThanh date not null,
	trangThai nvarchar(50) not null,
)

/*Tạo bảng địa chỉ*/
CREATE TABLE DiaDiem
(
	maCT nchar(20),
	soNha nvarchar(20) not null,
	tenDuong nvarchar(50) not null,
	tenPhuong nvarchar(50) not null,
	tenQuan nvarchar(50) not null,

	FOREIGN KEY (maCT) REFERENCES CongTrinh(maCT)
)

/*Thêm dữ liệu vào bảng công trình*/
INSERT INTO CongTrinh (maCT, tenCT, loaiCT, ngayKhoiCong, ngayHoanThanh, trangThai)
VALUES 
('CT001', N'Căn hộ Central Garden', 'Chung cư', '2016-04-20', '2022-05-10', N'Hoàn thành'),
('CT002', N'Căn hộ Ánh Dương', N'Chung cư', '2019-06-20', '2023-05-10', N'Đang thi công'),
('CT003', N'Chung cư Thế Hệ Mới',N'Chung cư', '2017-04-23', '2021-06-10', N'Hoàn thành'),
('CT004', N'The Krista Apartment',N'Chung cư', '2020-04-24', '2024-05-26', N'Đang thi công'),
('CT005', N'Căn hộ Homyland 3',N'Chung cư', '2016-04-12', '2022-05-11', N'Hoàn thành'),
('CT006', N'Căn hộ River Gate',N'Chung cư', '2020-11-26', '2025-05-12', N'Đang thi công'),
('CT007', N'Chung Cư Luxcity',N'Chung cư', '2018-04-12', '2024-05-20', N'Đang thi công'),
('CT008', N'Phu Nhuan Halo Serviced Apartment',N'Chung cư', '2022-10-10', '2026-09-21', N'Đang thi công'),
('CT009', N'Chung cư Osimi Tower',N'Chung cư', '2016-04-22', '2022-12-26', N'Đang thi công'),
('CT010', N'Sunny Plaza',N'Chung cư', '2021-04-24', '2026-07-25', N'Đang thi công');




DROP TABLE CongTrinh

INSERT INTO DiaDiem (soNha, tenDuong, tenPhuong, tenQuan, maCT)
VALUES
(N'328', N'Võ Văn Kiệt', N'Phường Cô Giang', N'Quận 1', 'CT001'),
(N'1208/20', N'Quang Trung', N'Phường 10', N'Quận Gò Vấp', 'CT002'),
(N'17', N'Hồ Hảo Hớn', N'Phường Cô Giang', N'Quận 1', 'CT003'),
(N'537', N'Nguyễn Duy Trinh', N'Phường 12', N'Quận 2', 'CT004'),
(N'403A', N'Nguyễn Duy Trinh', N'Phường Bình Trưng Tây', N'Quận 2', 'CT005'),
(N'336', N'Nguyễn Văn Luông', N'Phường 12', N'Quận 6', 'CT006'),
(N'528', N'Huỳnh Tấn Phát', N'Phường Bình Thuận', N'Quận Phú Nhuận', 'CT007'),
(N'61', N'Trần Kế Xương', N'Phường 3', N'Quận Phú Nhuận', 'CT008'),
(N'688/57', N'Lê Đức Thọ', N'Phường 15', N'Quận Gò Vấp', 'CT009'),
(N'110a', N'Phạm Văn Đồng', N'Phường 3', N'Quận Gò Vấp', 'CT010');

select * from DiaDiem
select * from CongTrinh

DROP TABLE DiaDiem

select CongTrinh.maCT, CongTrinh.tenCT, CongTrinh.loaiCT, CongTrinh.ngayKhoiCong, CongTrinh.ngayHoanThanh, CongTrinh.trangThai,
		DiaDiem.soNha, DiaDiem.tenDuong, DiaDiem.tenPhuong, DiaDiem.tenQuan
from CongTrinh
inner join DiaDiem on CongTrinh.maCT = DiaDiem.maCT; 

select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT

select * from [QuanLiLaoDong].[dbo].[CongTrinh] where [maCT] = 'CT0012';

--Update CongTrinh set tenCT = ?, loaiCT= ?, ngayKhoiCong=?, ngayHoanThanh=?, trangThai=? where maCT = 'CT001';

select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where ct.loaiCT = N'Chung cư';

select * from [dbo].[CongTrinh] as ct  join [dbo].[DiaDiem] as dd on ct.maCT = dd.maCT where soNha = N'120a';